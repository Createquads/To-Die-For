"""
Converts the supplied Dealer artwork into assets/dealer.png.

    python3 tools/convert_dealer.py path/to/Dealer.png

The source is a large soft-edged render rather than clean pixel data
(60k+ colours, ~11px blocks that do not sit on a strict grid), so it
gets resampled down to the artist's intended pixel density, quantised
to a tight palette, and keyed to transparency.

Three things this has to get right, each of which broke a first attempt:

1. KEY AT FULL RESOLUTION, NOT AFTER DOWNSAMPLING. Averaging a block
   that straddles the figure's edge mixes suit with backdrop, which
   left a white halo all around the silhouette. Here the background is
   identified first, and each output pixel averages ONLY source pixels
   that belong to the figure.

2. FORCE THE TIE INTO THE PALETTE. PIL's quantiser is area-weighted and
   the tie is about 1% of the figure, so it lost its bin entirely and
   the red vanished. The tie colour is added to the palette by hand.

3. SKIN IS NOT SIMPLY "REDDISH". A cleanup pass that removed stray
   warm pixels from the shoulders also erased the tie, because the tie
   passes any red-ish test. Skin carries plenty of green; the tie's
   green is near zero, which is what separates them.
"""
import sys
import numpy as np
from collections import Counter
from scipy import ndimage
from PIL import Image

SRC = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/uploads/Dealer.png"
TARGET_W = 240      # the artist's own pixel density
UPSCALE = 4
TIE = np.array([228.0, 20.0, 32.0])

src = Image.open(SRC).convert("RGB")
A = np.asarray(src).astype(float)

# --- 1. background, found at full resolution -------------------------
pale = (A.min(2) > 214) & ((A.max(2) - A.min(2)) < 30)
lab, _ = ndimage.label(pale)
border = set(lab[0].tolist()) | set(lab[-1].tolist()) | set(lab[:, 0].tolist()) | set(lab[:, -1].tolist())
border.discard(0)
fig = ~np.isin(lab, list(border))       # anything not reachable from the edge

ys, xs = np.where(fig)
A = A[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
fig = fig[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
h, w, _ = A.shape

# --- 2. downsample, averaging only figure pixels ---------------------
TH = max(1, round(h * TARGET_W / w))
yb = (np.arange(TH + 1) * h / TH).astype(int)
xb = (np.arange(TARGET_W + 1) * w / TARGET_W).astype(int)
rgb = np.zeros((TH, TARGET_W, 3))
cov = np.zeros((TH, TARGET_W))
for j in range(TH):
    for i in range(TARGET_W):
        sl = (slice(yb[j], max(yb[j + 1], yb[j] + 1)), slice(xb[i], max(xb[i + 1], xb[i] + 1)))
        m = fig[sl]
        cov[j, i] = m.mean()
        rgb[j, i] = A[sl][m].mean(0) if m.any() else 255.0
alpha = cov >= 0.5

# --- 3. palette from the figure alone, with the tie forced in --------
pal_src = rgb[alpha].reshape(-1, 1, 3).astype(np.uint8)
pq = Image.fromarray(pal_src).quantize(colors=22, method=Image.MEDIANCUT,
                                       dither=Image.Dither.NONE)
pal = np.array(pq.getpalette()[:22 * 3]).reshape(-1, 3).astype(float)
pal = np.vstack([pal, TIE, TIE * 0.72])

flat = rgb.reshape(-1, 3)
idx = np.argmin(((flat[:, None, :] - pal[None, :, :]) ** 2).sum(2), axis=1)
out = pal[idx].reshape(TH, TARGET_W, 3)

# --- 4. tidy stray skin tones off the shoulders ----------------------
R, G, B = out[:, :, 0], out[:, :, 1], out[:, :, 2]
skinlike = (R > 150) & (G > 110) & (R > B + 25) & alpha   # green is what excludes the tie
rows = np.arange(TH)[:, None].repeat(TARGET_W, 1)
hands_top = 0.70                                          # hands start below this
for y, x in zip(*np.where(skinlike & (rows < TH * hands_top))):
    y0, y1 = max(y - 2, 0), min(y + 3, TH)
    x0, x1 = max(x - 2, 0), min(x + 3, TARGET_W)
    nb = out[y0:y1, x0:x1].reshape(-1, 3)
    na = alpha[y0:y1, x0:x1].reshape(-1)
    ok = ~((nb[:, 0] > 150) & (nb[:, 1] > 110) & (nb[:, 0] > nb[:, 2] + 25))
    pick = nb[na & ok]
    if len(pick):
        out[y, x] = Counter(map(tuple, pick)).most_common(1)[0][0]

img = Image.fromarray(np.dstack([out, np.where(alpha, 255, 0)]).astype(np.uint8), "RGBA")
img.resize((TARGET_W * UPSCALE, TH * UPSCALE), Image.NEAREST).save("assets/dealer.png")
print("wrote assets/dealer.png (%dx%d)" % (TARGET_W * UPSCALE, TH * UPSCALE))

# --- palm anchors, measured from the skin blobs themselves -----------
f = np.asarray(img).astype(int)
sk = (f[:, :, 3] > 0) & (f[:, :, 0] > 170) & (f[:, :, 1] > 110) & (f[:, :, 0] > f[:, :, 2] + 25)
lab2, n2 = ndimage.label(sk)
sizes = ndimage.sum(sk, lab2, range(1, n2 + 1))
blobs = []
for k in [i + 1 for i, s in enumerate(sizes) if s > 40]:
    yy, xx = np.where(lab2 == k)
    blobs.append((xx.mean() / TARGET_W, yy.min() / TH))
blobs.sort()
print("palm anchors for Scenes/title_animation.gd:")
for i, (fx, fy) in enumerate(blobs):
    print("   palm %d: (%.3f, %.3f)" % (i, fx, fy))
