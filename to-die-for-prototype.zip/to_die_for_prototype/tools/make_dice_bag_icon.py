"""
Generates assets/dice_bag_icon.png -- the clickable dice-bag icon.

Drawn as true pixel art on a 32x32 grid, then scaled up 8x with
nearest-neighbour so every pixel stays a hard square (no blur).
Palette is dark purple + gold with a solid black 1px outline, to
match the wood/felt dice tray without competing with it.

Re-run this if you want to tweak the shape or colors:
    python3 tools/make_dice_bag_icon.py
"""
from PIL import Image

GRID = 32
SCALE = 8

# --- palette -------------------------------------------------------
CLEAR      = (0, 0, 0, 0)
OUTLINE    = (0, 0, 0, 255)
P_SHADOW   = (42, 20, 53, 255)     # deepest purple, bottom/left of the pouch
P_MID      = (74, 33, 96, 255)     # main body purple
P_LIGHT    = (107, 48, 136, 255)   # lit side of the pouch
P_HILITE   = (139, 71, 168, 255)   # top highlight where light catches
G_DARK     = (138, 106, 30, 255)   # gold in shadow
G_MID      = (201, 162, 39, 255)   # main gold (drawstring band)
G_LITE     = (240, 212, 92, 255)   # gold highlight + pips
MOUTH      = (24, 11, 31, 255)     # dark opening at the very top

img = Image.new("RGBA", (GRID, GRID), CLEAR)
px = img.load()

CX = 16  # horizontal centre of the bag

# Half-width of the pouch body at each row -- hand-tuned so it bulges
# out below the drawstring and tucks back in at the base.
BODY = {
	10: 6, 11: 7, 12: 9, 13: 10, 14: 11, 15: 11, 16: 12, 17: 12,
	18: 12, 19: 12, 20: 12, 21: 12, 22: 11, 23: 11, 24: 10, 25: 9,
	26: 8, 27: 6,
}
# Gathered fabric above the drawstring, and the drawstring band itself.
NECK = {4: 4, 5: 4, 6: 5, 7: 5}
BAND = {8: 6, 9: 6}


def put(x, y, color):
	# Writes one pixel, ignoring anything that falls off the grid.
	if 0 <= x < GRID and 0 <= y < GRID:
		px[x, y] = color


# Light source sits up and to the left of the pouch, so shading is
# picked by distance from that point rather than by a flat left/right
# split -- that's what makes it read as a sphere instead of a stripe.
LIGHT_X, LIGHT_Y = CX - 6.0, 13.0


def shade(x, y, half):
	# Picks a purple by how far this pixel is from the light source,
	# normalised against the pouch's own width so the ramp stays
	# consistent on narrow rows near the top and bottom.
	dx = (x - LIGHT_X) / float(half)
	dy = (y - LIGHT_Y) / 11.0
	d = (dx * dx + dy * dy) ** 0.5
	if d < 0.45:
		return P_HILITE
	if d < 0.95:
		return P_LIGHT
	if d < 1.45:
		return P_MID
	return P_SHADOW


# --- body ----------------------------------------------------------
for y, half in BODY.items():
	for x in range(CX - half, CX + half + 1):
		put(x, y, shade(x, y, half))

# --- gathered neck above the band ----------------------------------
for y, half in NECK.items():
	for x in range(CX - half, CX + half + 1):
		put(x, y, P_MID if x >= CX else P_LIGHT)

# --- dark mouth at the very top ------------------------------------
for x in range(CX - 3, CX + 4):
	put(x, 3, MOUTH)
	put(x, 4, MOUTH if abs(x - CX) < 3 else P_LIGHT)

# --- gold drawstring band ------------------------------------------
for y, half in BAND.items():
	for x in range(CX - half, CX + half + 1):
		if x < CX - 2:
			put(x, y, G_LITE)
		elif x < CX + 3:
			put(x, y, G_MID)
		else:
			put(x, y, G_DARK)

# Two gold string ends trailing off the right of the knot.
for i, y in enumerate((10, 11, 12)):
	put(CX + 6 + i, y, G_MID)
	put(CX + 7 + i, y, G_DARK)

# --- gold pips on the pouch face (a die's "three" face) ------------
for (pxx, pyy) in ((CX - 4, 15), (CX, 18), (CX + 4, 21)):
	put(pxx, pyy, G_LITE)
	put(pxx + 1, pyy, G_LITE)
	put(pxx, pyy + 1, G_MID)
	put(pxx + 1, pyy + 1, G_MID)

# --- black outline -------------------------------------------------
# Any transparent pixel orthogonally touching a filled one becomes
# outline, which traces the whole silhouette in one pass.
filled = {(x, y) for y in range(GRID) for x in range(GRID) if px[x, y][3] > 0}
for (x, y) in list(filled):
	for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
		nx, ny = x + dx, y + dy
		if 0 <= nx < GRID and 0 <= ny < GRID and (nx, ny) not in filled:
			put(nx, ny, OUTLINE)

img.resize((GRID * SCALE, GRID * SCALE), Image.NEAREST).save(
	"assets/dice_bag_icon.png"
)
print("wrote assets/dice_bag_icon.png (%dx%d)" % (GRID * SCALE, GRID * SCALE))
