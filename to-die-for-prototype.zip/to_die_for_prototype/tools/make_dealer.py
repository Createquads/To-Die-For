"""
SUPERSEDED -- kept only for reference.

assets/dealer.png is now built from hand-drawn art supplied by the
project owner, converted by tools/convert_dealer.py. This script drew
the figure from scratch and its output looked stiff by comparison,
particularly the hands: the drawn fingers were flat blocks, where the
supplied art shades between them and reads far more naturally.

Running this writes to tools/generated/ and changes nothing in the game.
"""

import os
from PIL import Image, ImageDraw

W, H = 320, 200          # 1.60, near the reference's 1.63
SCALE = 3
CX = 160

C = {
    "clear":     (0, 0, 0, 0),
    "void":      (10, 9, 24, 255),     # head, hair, shirt -- all one dark mass
    "void_hi":   (28, 28, 46, 255),
    "coat":      (6, 6, 13, 255),      # jacket, near black
    "coat_hi":   (38, 42, 57, 255),    # the cool sheen along sleeves and shoulders
    # Reading the reference again: the LAPELS are the mid-grey shapes
    # flanking the tie, and the shirt behind them is nearly black. I had
    # these the wrong way round, which is why the chest read as a slab.
    "shirt":     (13, 12, 27, 255),
    "shirt_hi":  (26, 26, 44, 255),
    "lapel":     (56, 60, 78, 255),
    "lapel_hi":  (84, 89, 110, 255),
    "tie":       (214, 18, 32, 255),
    "tie_hi":    (248, 62, 62, 255),
    "skin":      (250, 226, 206, 255),
    "skin_mid":  (232, 186, 152, 255),
    "skin_sh":   (204, 138, 100, 255),
    "skin_line": (116, 60, 36, 255),   # hands are outlined in brown, not black
    "outline":   (0, 0, 0, 255),
}

img = Image.new("RGBA", (W, H), C["clear"])
d = ImageDraw.Draw(img)
PALMS = []


def hand(hx, hy, side):
    """
    An open palm turned up, fingers splayed away from the body.

    The fingers are drawn ON TOP of the palm with clear gaps between
    them -- laid underneath they merged into the palm ellipse and the
    hand came out looking like a mitten. Outlined in brown rather than
    black, which is what keeps skin readable against an almost entirely
    black figure.
    """
    # palm first
    d.ellipse([hx - 20, hy - 14, hx + 20, hy + 16], fill=C["skin_mid"], outline=C["skin_line"])
    d.ellipse([hx - 17, hy - 14, hx + 17, hy + 7], fill=C["skin"])
    d.ellipse([hx - 11, hy - 1, hx + 14, hy + 13], fill=C["skin_sh"])

    # four fingers reaching outward, each its own shape with a gap
    for i in range(4):
        reach = 34 - abs(i - 1) * 4
        fy = hy - 16 + i * 9
        x0, x1 = sorted((hx + side * 8, hx + side * reach))
        d.rounded_rectangle([x0, fy, x1, fy + 6], radius=3,
                            fill=C["skin"], outline=C["skin_line"])
        d.rounded_rectangle([x0, fy + 4, x1, fy + 6], radius=2, fill=C["skin_mid"])

    # thumb, angled up and inward
    tx0, tx1 = sorted((hx - side * 6, hx + side * 10))
    d.rounded_rectangle([tx0, hy - 28, tx1, hy - 12], radius=5,
                        fill=C["skin"], outline=C["skin_line"])
    PALMS.append((hx, hy - 22))


# --- head: skull, jaw and hair as one unbroken silhouette ------------
d.ellipse([137, 12, 183, 62], fill=C["void"])                       # skull
d.polygon([(141, 44), (179, 44), (174, 74), (160, 82), (146, 74)], fill=C["void"])  # jaw
# hair as one solid cap. The earlier version was a ring of points with
# a highlight across it, which left a bright notch on the crown.
d.polygon([(136, 34), (139, 14), (148, 4), (172, 4), (181, 14), (184, 34),
           (178, 22), (160, 16), (142, 22)], fill=C["void"])
d.polygon([(151, 74), (169, 74), (172, 94), (148, 94)], fill=C["void"])  # neck

# --- shoulders and jacket --------------------------------------------
d.polygon([(92, 200), (96, 98), (122, 80), (198, 80), (224, 98), (228, 200)], fill=C["coat"])
d.polygon([(100, 96), (124, 82), (132, 87), (108, 103), (104, 200), (96, 200)], fill=C["coat_hi"])
d.polygon([(220, 96), (196, 82), (190, 87), (212, 103), (216, 200)], fill=C["coat_hi"])

# --- shirt and tie ----------------------------------------------------
# The jacket opens in a wide V. Earlier the lapels were so broad they
# covered the whole chest and the shirt never showed at all.
d.polygon([(116, 84), (160, 182), (204, 84), (204, 200), (116, 200)], fill=C["shirt"])
d.polygon([(160, 182), (204, 84), (204, 104), (160, 194)], fill=C["shirt_hi"])
d.polygon([(138, 84), (160, 98), (153, 110), (133, 94)], fill=C["shirt_hi"])
d.polygon([(182, 84), (160, 98), (167, 110), (187, 94)], fill=C["shirt"])
d.polygon([(153, 92), (167, 92), (169, 106), (151, 106)], fill=C["tie"])
d.polygon([(153, 92), (160, 92), (160, 106), (151, 106)], fill=C["tie_hi"])
d.polygon([(152, 106), (168, 106), (166, 168), (160, 182), (154, 168)], fill=C["tie"])
d.polygon([(152, 106), (159, 106), (158, 168), (154, 168)], fill=C["tie_hi"])

# --- lapels: narrow strips along the V, not slabs across the chest ---
# broad panels either side of the opening -- these are the pale shapes
# that give the suit its shape in the reference
d.polygon([(96, 98), (124, 82), (160, 182), (134, 176)], fill=C["lapel"])
d.polygon([(224, 98), (196, 82), (160, 182), (186, 176)], fill=C["lapel"])
d.polygon([(96, 98), (124, 82), (127, 90), (101, 106)], fill=C["lapel_hi"])
d.polygon([(224, 98), (196, 82), (193, 90), (219, 106)], fill=C["lapel_hi"])

# --- arms: shoulder out and down to the wrists ------------------------
for side in (-1, 1):
    sx = CX + side * 58
    ex = CX + side * 104     # elbow
    wx = CX + side * 116     # wrist
    # heavy, so they read as suit sleeves rather than wire
    d.polygon([(sx, 84), (sx + side * 34, 100), (ex + side * 22, 152), (ex - side * 16, 134)],
              fill=C["coat"])
    d.polygon([(ex + side * 22, 152), (ex - side * 16, 134), (wx - side * 4, 168),
               (wx + side * 22, 178)], fill=C["coat"])
    # sheen down the outer edge of the sleeve
    d.polygon([(sx + side * 22, 98), (sx + side * 26, 100), (ex + side * 16, 150),
               (ex + side * 10, 148)], fill=C["coat_hi"])
    # shirt cuff at the wrist
    d.polygon([(wx - side * 6, 162), (wx + side * 12, 174), (wx + side * 18, 166),
               (wx, 154)], fill=C["shirt"])

# --- jacket details ---------------------------------------------------
d.ellipse([157, 156, 163, 162], fill=C["coat_hi"])        # button
d.rectangle([112, 176, 138, 181], fill=C["lapel"])         # pockets
d.rectangle([182, 176, 208, 181], fill=C["lapel"])

# hands last, so they sit over the cuffs
hand(CX - 134, 166, -1)
hand(CX + 134, 166, 1)

# --- outline pass -----------------------------------------------------
# Traces the silhouette against empty space. The hands already carry
# their own brown outline, so this only tightens the suit.
px = img.load()
filled = {(x, y) for y in range(H) for x in range(W) if px[x, y][3] > 0}
edge = set()
for (x, y) in filled:
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        nx, ny = x + dx, y + dy
        if 0 <= nx < W and 0 <= ny < H and (nx, ny) not in filled:
            edge.add((nx, ny))
for (x, y) in edge:
    px[x, y] = C["outline"]

os.makedirs("tools/generated", exist_ok=True)
img.resize((W * SCALE, H * SCALE), Image.NEAREST).save("tools/generated/dealer.png")
print("wrote tools/generated/dealer.png (%dx%d) -- not wired into the game" % (W * SCALE, H * SCALE))
print("palm anchors as fractions:")
for i, (pxx, pyy) in enumerate(PALMS):
    print("   palm %d: (%.4f, %.4f)" % (i, pxx / float(W), pyy / float(H)))
