"""
Generates assets/dice_sheet.png -- the die sprite sheet.

The dice are a real cube: eight corners rotated in 3D, orthographically
projected, back-face culled and lit per-face. That's what gives the
sides genuine perspective, and it means the tumble row is an actual
rotating cube rather than a flat sprite being squashed.

Face numbering follows a standard die, taken from the unfolded net:
opposite faces sum to 7 (1-6, 2-5, 3-4). Because the cube is real, the
two side faces visible in any frame are automatically ones genuinely
adjacent to the top face -- picking them by hand is how you end up
drawing an impossible die.

    row 0 : three-quarter hero views, faces 1-6 (cells 0-5)
    row 1 : 8-frame tumble loop

Writes to tools/generated/. The live art in assets/ has been edited by
hand since, so this script deliberately cannot overwrite it.

Art is composed at LOGICAL px then scaled up with nearest-neighbour, so
the pixels stay chunky and in keeping with the dice tray.

    python3 tools/make_dice_sheet.py            # ivory
    python3 tools/make_dice_sheet.py crimson
"""
import math
import os
import sys
from PIL import Image, ImageDraw

# Doubled from the first pass. The art is genuinely composed at this
# resolution rather than upscaled, so it holds more detail -- which
# shows on high-DPI screens, where the canvas_items stretch renders at
# the device resolution instead of the 1280x720 base.
CELL = 256          # final sprite size
LOGICAL = 128       # art is drawn at this size, then doubled
SCALE = CELL // LOGICAL
UNIT = LOGICAL / 64.0   # everything below is expressed against this
COLS, ROWS = 8, 2
PREVIEW = 3

CLEAR = (0, 0, 0, 0)
OUTLINE = (0, 0, 0, 255)

# four body shades, brightest first, plus the pip colour
PALETTES = {
    "ivory":   [(250, 246, 230), (231, 223, 190), (191, 180, 143), (146, 135, 100), (44, 34, 22)],
    "crimson": [(238, 116, 112), (206, 62, 62), (158, 38, 40), (108, 24, 28), (248, 216, 96)],
    "violet":  [(198, 142, 228), (152, 88, 188), (112, 58, 146), (74, 34, 100), (246, 234, 128)],
    "jade":    [(140, 230, 158), (74, 182, 104), (48, 138, 78), (28, 92, 52), (24, 46, 30)],
}
NAME = sys.argv[1] if len(sys.argv) > 1 else "ivory"
SHADES = PALETTES[NAME][:4]
PIP = PALETTES[NAME][4]

# pip layout on a 3x3 grid, as (column, row) with 0..2
PIPS = {
    1: [(1, 1)],
    2: [(0, 0), (2, 2)],
    3: [(0, 0), (1, 1), (2, 2)],
    4: [(0, 0), (2, 0), (0, 2), (2, 2)],
    5: [(0, 0), (2, 0), (1, 1), (0, 2), (2, 2)],
    6: [(0, 0), (2, 0), (0, 1), (2, 1), (0, 2), (2, 2)],
}

# Which value sits on which face of the cube, and the two in-face axes
# used to lay its pips out. Read straight off the unfolded net: with 1
# facing front, 3 folds up, 4 down, 5 left, 2 right and 6 to the back.
#              normal        u axis        v axis (down the face)
FACES = {
    1: ((0, 0, 1), (1, 0, 0), (0, -1, 0)),
    6: ((0, 0, -1), (-1, 0, 0), (0, -1, 0)),
    3: ((0, 1, 0), (1, 0, 0), (0, 0, 1)),
    4: ((0, -1, 0), (1, 0, 0), (0, 0, -1)),
    2: ((1, 0, 0), (0, 0, -1), (0, -1, 0)),
    5: ((-1, 0, 0), (0, 0, 1), (0, -1, 0)),
}

H = 16.5 * UNIT     # half the cube's edge
PIP_R = 0.17        # pip size as a fraction of the face
LIGHT = (-0.42, 0.78, 0.46)


def rot_x(p, a):
    y, z = p[1] * math.cos(a) - p[2] * math.sin(a), p[1] * math.sin(a) + p[2] * math.cos(a)
    return (p[0], y, z)


def rot_y(p, a):
    x, z = p[0] * math.cos(a) + p[2] * math.sin(a), -p[0] * math.sin(a) + p[2] * math.cos(a)
    return (x, p[1], z)


def rot_z(p, a):
    x, y = p[0] * math.cos(a) - p[1] * math.sin(a), p[0] * math.sin(a) + p[1] * math.cos(a)
    return (x, y, p[2])


def view(p):
    """The fixed three-quarter camera: classic isometric angles."""
    p = rot_y(p, math.radians(45.0))
    # positive pitch tilts +Y toward the camera. Negative put the camera
    # underneath the die, so every frame showed the bottom face.
    p = rot_x(p, math.radians(35.264))
    return p


def project(p):
    """Orthographic, so opposite edges stay parallel like real iso art."""
    return (LOGICAL * 0.5 + p[0], LOGICAL * 0.5 - p[1] + 2.0 * UNIT)


def shade_for(normal_cam):
    """
    Lambert against a fixed light, quantised to four steps. Quantising is
    what keeps it reading as pixel art -- a smooth gradient across each
    face would look like a render, not a sprite.
    """
    d = sum(normal_cam[i] * LIGHT[i] for i in range(3))
    d = max(d, 0.0)
    idx = 0 if d > 0.80 else 1 if d > 0.52 else 2 if d > 0.24 else 3
    return SHADES[idx]


def cube(value, spin=(0.0, 0.0, 0.0)):
    """
    Render the die with `value` face up, optionally spun for the tumble.
    Faces are back-face culled and drawn far-to-near.
    """
    img = Image.new("RGBA", (LOGICAL, LOGICAL), CLEAR)
    d = ImageDraw.Draw(img)

    # bring the wanted value to the top (+Y) before anything else
    align = {
        3: lambda p: p,
        1: lambda p: rot_x(p, math.radians(-90)),
        6: lambda p: rot_x(p, math.radians(90)),
        4: lambda p: rot_x(p, math.radians(180)),
        2: lambda p: rot_z(p, math.radians(90)),
        5: lambda p: rot_z(p, math.radians(-90)),
    }[value]

    def to_cam(p):
        p = align(p)
        p = rot_x(p, spin[0])
        p = rot_y(p, spin[1])
        p = rot_z(p, spin[2])
        return view(p)

    # contact shadow, squashed and offset so the die reads as resting
    d.ellipse([LOGICAL * 0.5 - 17 * UNIT, LOGICAL - 17 * UNIT,
               LOGICAL * 0.5 + 17 * UNIT, LOGICAL - 7 * UNIT],
              fill=(0, 0, 0, 70))

    drawn = []
    for val, (n, u, v) in FACES.items():
        n_cam = to_cam(n)
        if n_cam[2] <= 0.02:          # facing away from camera
            continue
        centre = tuple(n[i] * H for i in range(3))
        corners = []
        for su, sv in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            p = tuple(centre[i] + u[i] * H * su + v[i] * H * sv for i in range(3))
            corners.append(to_cam(p))
        depth = sum(c[2] for c in corners) / 4.0
        drawn.append((depth, val, n_cam, centre, u, v, corners))

    # nearest last, so closer faces paint over further ones
    drawn.sort(key=lambda f: f[0])

    for depth, val, n_cam, centre, u, v, corners in drawn:
        body = shade_for(n_cam)
        pts = [project(c) for c in corners]
        d.polygon(pts, fill=body, outline=OUTLINE, width=int(UNIT))

        # No catch-light along the upper edges. It was there originally,
        # but it broke up the silhouette -- every edge now carries the
        # same solid black outline, which reads far cleaner at this size.

        for (cx, cy) in PIPS[val]:
            fu = (cx - 1) * 0.50
            fv = (cy - 1) * 0.50
            pip_pts = []
            for su, sv in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                a = fu + su * PIP_R
                b = fv + sv * PIP_R
                p = tuple(centre[i] + u[i] * H * a + v[i] * H * b for i in range(3))
                pip_pts.append(project(to_cam(p)))
            # pips share the face's shading band so they sink into it
            d.polygon(pip_pts, fill=PIP)
    return img


def hero(value):
    return cube(value)


def tumble(frame, total=8):
    """
    A genuine 3D tumble: the cube turns on two axes at once, so the face
    presented to the camera changes through the loop. Earlier versions
    faked this by squashing a flat sprite, which never looked like the
    die had sides.
    """
    t = frame / float(total)
    spin = (math.tau * t, math.tau * t * 0.5, math.radians(18.0 * math.sin(math.tau * t)))
    img = cube(1, spin)

    d = ImageDraw.Draw(img)
    a = (frame * 45) % 360
    d.arc([UNIT, UNIT, LOGICAL - 2 * UNIT, LOGICAL - 2 * UNIT], a, a + 62,
          fill=(255, 255, 255, 215), width=int(UNIT))
    d.arc([UNIT, UNIT, LOGICAL - 2 * UNIT, LOGICAL - 2 * UNIT], a + 180, a + 242,
          fill=(255, 255, 255, 150), width=int(UNIT))
    return img


sheet = Image.new("RGBA", (CELL * COLS, CELL * ROWS), CLEAR)
for i in range(6):
    sheet.paste(hero(i + 1).resize((CELL, CELL), Image.NEAREST), (CELL * i, 0))
for i in range(8):
    sheet.paste(tumble(i).resize((CELL, CELL), Image.NEAREST), (CELL * i, CELL))

# Output goes to tools/generated/, NOT assets/. The sheets in assets/
# carry hand edits made outside this script, and having a regenerate
# silently clobber them is a trap worth designing out. Copy across
# deliberately if you want generated art to become the real art.
suffix = "" if NAME == "ivory" else "_" + NAME
os.makedirs("tools/generated", exist_ok=True)
sheet.save("tools/generated/dice_sheet%s.png" % suffix)
os.makedirs("tools/previews", exist_ok=True)
sheet.resize((sheet.width // 2, sheet.height // 2), Image.NEAREST) \
     .save("tools/previews/dice_sheet%s_preview.png" % suffix)
print("wrote tools/generated/dice_sheet%s.png (%dx%d, %d cells of %dpx)"
      % (suffix, sheet.width, sheet.height, COLS * ROWS, CELL))
