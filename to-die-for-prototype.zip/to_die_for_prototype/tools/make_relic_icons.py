"""
Generates assets/relic_icons.png -- an 8x4 sheet of 64px relic emblems.

Hand-drawing an icon per relic does not survive the plan of eventually
having hundreds of them, so each emblem is built from a small grammar
instead: a tier-coloured frame, one of several ring styles, and a
central glyph chosen by index. Distinct enough to tell apart at a
glance, and emblem number 200 costs nothing to add.

Tier colour carries the rarity, so a mythic reads as mythic before the
player has learned any individual icon.
"""
import math
import os
from PIL import Image, ImageDraw

CELL, COLS, ROWS, SCALE = 64, 8, 4, 2
OUT = (0, 0, 0, 255)

# common / rare / mythic -> (frame, glyph, glow)
TIERS = [
    ((92, 104, 128), (206, 216, 236), (52, 60, 78)),      # common: cold steel
    ((186, 140, 52), (250, 224, 138), (78, 54, 18)),      # rare: gold
    ((168, 74, 196), (244, 186, 255), (66, 26, 82)),      # mythic: arcane violet
]
# which tier each icon index belongs to, matching the catalog order
TIER_OF = [0]*9 + [1]*9 + [2]*7


def glyph(d, i, cx, cy, r, col):
    """One of several shapes, picked by index so every relic differs."""
    k = i % 8
    if k == 0:                                   # pip cluster
        for dx, dy in ((-1,-1),(1,-1),(-1,1),(1,1)):
            d.ellipse([cx+dx*r*0.45-3, cy+dy*r*0.45-3, cx+dx*r*0.45+3, cy+dy*r*0.45+3], fill=col)
    elif k == 1:                                 # upward chevrons
        for o in (-5, 2):
            d.polygon([(cx-r*0.6, cy+o+4), (cx, cy+o-5), (cx+r*0.6, cy+o+4)], fill=col)
    elif k == 2:                                 # diamond
        d.polygon([(cx, cy-r*0.7), (cx+r*0.6, cy), (cx, cy+r*0.7), (cx-r*0.6, cy)], fill=col)
    elif k == 3:                                 # bar and dot
        d.rectangle([cx-r*0.6, cy-2, cx+r*0.6, cy+2], fill=col)
        d.ellipse([cx-4, cy-r*0.6-4, cx+4, cy-r*0.6+4], fill=col)
    elif k == 4:                                 # six-point star
        for a in range(6):
            t = a * math.pi / 3.0
            d.line([(cx, cy), (cx+math.cos(t)*r*0.7, cy+math.sin(t)*r*0.7)], fill=col, width=3)
    elif k == 5:                                 # split circle
        d.ellipse([cx-r*0.6, cy-r*0.6, cx+r*0.6, cy+r*0.6], outline=col, width=3)
        d.rectangle([cx-1, cy-r*0.6, cx+1, cy+r*0.6], fill=col)
    elif k == 6:                                 # coiled serpent-ish spiral
        pts = []
        for step in range(22):
            t = step / 21.0
            ang = t * math.pi * 2.4
            rad = r * 0.66 * (1.0 - t * 0.62)
            pts.append((cx + math.cos(ang)*rad, cy + math.sin(ang)*rad))
        d.line(pts, fill=col, width=3)
    else:                                        # hourglass
        d.polygon([(cx-r*0.5, cy-r*0.6), (cx+r*0.5, cy-r*0.6), (cx, cy)], fill=col)
        d.polygon([(cx-r*0.5, cy+r*0.6), (cx+r*0.5, cy+r*0.6), (cx, cy)], fill=col)


def emblem(i):
    img = Image.new("RGBA", (CELL, CELL), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    frame, gl, glow = TIERS[TIER_OF[i] if i < len(TIER_OF) else 0]
    cx = cy = CELL // 2
    # rounded plate, tinted by tier
    d.rounded_rectangle([4, 4, CELL-5, CELL-5], radius=9, fill=glow + (255,), outline=OUT, width=2)
    d.rounded_rectangle([7, 7, CELL-8, CELL-8], radius=7, outline=frame + (255,), width=2)
    # ring style varies so two relics of a tier still differ at a glance
    if i % 3 == 1:
        d.ellipse([13, 13, CELL-14, CELL-14], outline=frame + (255,), width=2)
    elif i % 3 == 2:
        for a in range(4):
            t = math.pi/4 + a*math.pi/2
            d.ellipse([cx+math.cos(t)*20-3, cy+math.sin(t)*20-3,
                       cx+math.cos(t)*20+3, cy+math.sin(t)*20+3], fill=frame + (255,))
    glyph(d, i, cx, cy, 18, gl + (255,))
    return img


sheet = Image.new("RGBA", (CELL*COLS, CELL*ROWS), (0, 0, 0, 0))
for i in range(COLS*ROWS):
    sheet.paste(emblem(i), (CELL*(i % COLS), CELL*(i // COLS)))
os.makedirs("assets", exist_ok=True)
sheet.resize((CELL*COLS*SCALE, CELL*ROWS*SCALE), Image.NEAREST).save("assets/relic_icons.png")
print("wrote assets/relic_icons.png (%dx%d, %d cells of %dpx)"
      % (CELL*COLS*SCALE, CELL*ROWS*SCALE, COLS*ROWS, CELL*SCALE))
