extends CanvasLayer
# Lets the player choose which dice to scrap. Opened by the shop when
# an item asks you to pick rather than removing something fixed --
# that's what finally makes it possible to get rid of a special die
# that stopped fitting the build, instead of only Basics.

signal picked(indices)
signal cancelled

@onready var grid: GridContainer = $Panel/Margin/VBox/Scroll/Grid
@onready var title_label: Label = $Panel/Margin/VBox/Title
@onready var hint: Label = $Panel/Margin/VBox/Hint
@onready var confirm: Button = $Panel/Margin/VBox/Buttons/ConfirmButton

var die_scene: PackedScene = load("res://Scenes/die.tscn")
var _need: int = 1
var _chosen: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false

func open(item_name: String, need: int) -> void:
	_need = need
	_chosen = []
	title_label.text = item_name
	_rebuild()
	visible = true

func _rebuild() -> void:
	for child in grid.get_children():
		child.queue_free()
	for i in range(Global.dice_bag.size()):
		grid.add_child(_make_entry(i))
	_refresh()

func _make_entry(index: int) -> Control:
	# one button per die in the bag, showing the die itself and its name
	var die = Global.dice_bag[index]
	var info: Dictionary = Global.DIE_CATALOG.get(die.kind, {})

	var btn := Button.new()
	btn.custom_minimum_size = Vector2(178, 62)
	btn.toggle_mode = true
	btn.set_meta("index", index)
	btn.toggled.connect(_on_entry_toggled.bind(index))

	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 8)
	row.set_anchors_preset(Control.PRESET_FULL_RECT)
	btn.add_child(row)

	var pad := Control.new()
	pad.custom_minimum_size = Vector2(6, 0)
	row.add_child(pad)

	var icon = die_scene.instantiate()
	row.add_child(icon)
	icon.setup(die.active_kind())
	icon.make_preview(6)

	var label := Label.new()
	label.text = info.get("name", die.kind)
	label.add_theme_font_size_override("font_size", 13)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.autowrap_mode = TextServer.AUTOWRAP_WORD
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(label)
	return btn

func _on_entry_toggled(pressed: bool, index: int) -> void:
	if pressed:
		if _chosen.size() >= _need:
			# already at the limit, so refuse and untick it again
			for child in grid.get_children():
				if child.get_meta("index") == index:
					child.set_pressed_no_signal(false)
			return
		_chosen.append(index)
	else:
		_chosen.erase(index)
	_refresh()

func _refresh() -> void:
	hint.text = "Choose %d to scrap  --  %d selected" % [_need, _chosen.size()]
	confirm.disabled = _chosen.size() != _need
	# grey out the rest once the quota is filled, so the limit is visible
	for child in grid.get_children():
		if not child.button_pressed:
			child.disabled = _chosen.size() >= _need

func _on_confirm_button_pressed() -> void:
	visible = false
	picked.emit(_chosen.duplicate())

func _on_cancel_button_pressed() -> void:
	# the purchase already went through, so cancelling just leaves the
	# bag alone -- warned about on the button itself
	visible = false
	cancelled.emit()
