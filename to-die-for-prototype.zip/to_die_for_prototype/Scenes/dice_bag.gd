extends Control
# The dice bag: a clickable pouch icon pinned to the bottom of the
# screen with a live count badge. Opening it pauses the game and
# blurs everything behind, the way a pause menu does, then lists what
# you own plus every die you haven't unlocked yet and what it takes.
# That locked list is the point -- it's where a player finds their
# reason to start another run.

@onready var bag_button: TextureButton = $BagButton
@onready var count_badge: Label = $BagButton/CountBadge
@onready var blur: ColorRect = $Blur
@onready var panel: PanelContainer = $BagPanel
@onready var owned_list: VBoxContainer = $BagPanel/Margin/VBox/Scroll/Lists/OwnedList
@onready var locked_list: VBoxContainer = $BagPanel/Margin/VBox/Scroll/Lists/LockedList
@onready var panel_title: Label = $BagPanel/Margin/VBox/Title

signal opened

var die_scene: PackedScene = load("res://Scenes/die.tscn")

func _ready() -> void:
	# the panel and its button keep running while the tree is paused,
	# otherwise the menu would freeze itself the moment it opened
	process_mode = Node.PROCESS_MODE_ALWAYS
	Global.bag_changed.connect(_on_bag_changed)
	Global.relics_changed.connect(func(_r): if panel.visible: _rebuild())
	_close()
	_on_bag_changed(Global.dice_bag)

func _on_bag_changed(bag) -> void:
	count_badge.text = str(bag.size())
	if panel.visible:
		_rebuild()

func is_open() -> bool:
	return panel.visible

func close() -> void:
	# public, because main.gd owns the Escape key: two nodes both
	# grabbing ui_cancel would race on who wins
	_close()

func _on_bag_button_pressed() -> void:
	if panel.visible:
		_close()
	else:
		_open()

func _on_close_button_pressed() -> void:
	_close()

func _open() -> void:
	_rebuild()
	opened.emit()
	blur.visible = true
	panel.visible = true
	get_tree().paused = true

func _close() -> void:
	blur.visible = false
	panel.visible = false
	get_tree().paused = false

func _rebuild() -> void:
	# left column: what's in the bag. right column: what's still locked
	for child in owned_list.get_children():
		child.queue_free()
	for child in locked_list.get_children():
		child.queue_free()

	panel_title.text = "Dice Bag  (%d / %d)" % [Global.dice_bag.size(), Global.bag_cap()]

	_add_heading(owned_list, "In your bag")
	var counts: Dictionary = Global.bag_counts()
	for kind in counts.keys():
		var info: Dictionary = Global.DIE_CATALOG.get(kind, {})
		_add_entry(owned_list, "%s  x%d" % [info.get("name", kind), counts[kind]],
			info.get("desc", ""), Color(0.94, 0.83, 0.36), kind)

	# relics first: they are permanent and rule-changing, so they are
	# the thing a player most needs reminding of mid-run
	_add_heading(locked_list, "Relics (%d)" % Global.owned_relics.size())
	if Global.owned_relics.is_empty():
		_add_entry(locked_list, "None yet",
			"Bought from the left half of the shop. Permanent for the run.",
			Color(0.6, 0.56, 0.68))
	for id in Global.owned_relics:
		var r: Dictionary = Global.RELICS[id]
		_add_entry(locked_list, r["name"], r["desc"], Color(0.86, 0.55, 0.98))

	var locked: Array = Global.locked_objectives()
	_add_heading(locked_list, "Still to unlock (%d)" % locked.size())
	if locked.is_empty():
		_add_entry(locked_list, "Everything unlocked", "You've earned every die in the game.", Color(0.55, 0.85, 0.55))
	for entry in locked:
		_add_entry(locked_list, entry["name"], entry["objective"], Color(0.62, 0.58, 0.70), entry["kind"], true)

func _add_heading(parent: VBoxContainer, text: String) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 19)
	l.add_theme_color_override("font_color", Color(0.88, 0.84, 0.95))
	parent.add_child(l)

func _add_entry(parent: VBoxContainer, title: String, subtitle: String, colour: Color,
		kind: String = "", dim: bool = false) -> void:
	# one row: a small picture of the actual die, then its name and what
	# it does. the picture matters because a name like "Sable Die" tells
	# a new player nothing about what they'd be looking at on the tray
	var outer := HBoxContainer.new()
	outer.add_theme_constant_override("separation", 10)

	if kind != "":
		var icon = die_scene.instantiate()
		outer.add_child(icon)
		icon.setup(kind)
		icon.make_preview(6)
		# locked dice show washed out, so the list reads at a glance
		icon.modulate = Color(1, 1, 1, 0.35) if dim else Color.WHITE

	var row := VBoxContainer.new()
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation", 0)
	outer.add_child(row)

	var heading := Label.new()
	heading.text = title
	heading.add_theme_font_size_override("font_size", 16)
	heading.add_theme_color_override("font_color", colour)
	row.add_child(heading)

	var desc := Label.new()
	desc.text = subtitle
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD
	desc.custom_minimum_size = Vector2(300, 0)
	desc.add_theme_font_size_override("font_size", 12)
	desc.add_theme_color_override("font_color", Color(0.70, 0.65, 0.78))
	row.add_child(desc)

	parent.add_child(outer)

func focus_node(key: String) -> Control:
	match key:
		"bag": return bag_button
	return null
