extends Control
# Bust screen. Its own scene, switched to with change_scene_to_packed.
# Global survives the scene change, so the final numbers are still
# there -- and more importantly so is the unlock progress, which is
# what this screen is really here to show off.


@onready var summary_label: Label = $CenterContainer/VBox/SummaryLabel
@onready var unlock_label: Label = $CenterContainer/VBox/UnlockLabel
@onready var next_label: Label = $CenterContainer/VBox/NextLabel

func _ready() -> void:
	var unlocked: int = Global.unlocked_die_kinds.size()
	var total: int = Global.DIE_CATALOG.size()
	summary_label.text = "You went bust on Round %d of %d.\nBest ever: Round %d   Runs: %d" % [
		Global.round_number, Global.target_round(), Global.best_round, Global.runs_played
	]
	unlock_label.text = "Dice unlocked: %d of %d -- every one of them is in the shop on your next run." % [unlocked, total]
	next_label.text = _next_goals()

func _next_goals() -> String:
	# dangle two things still within reach, so the bust screen ends on
	# a reason to go again rather than on the loss
	var locked: Array = Global.locked_objectives()
	if locked.is_empty():
		return "Every die is unlocked. Now just see how far you can climb."
	locked.shuffle()
	var lines: Array = ["Still out there:"]
	for i in range(min(2, locked.size())):
		lines.append("   %s  --  %s" % [locked[i]["name"], locked[i]["objective"]])
	return "\n".join(lines)

func _on_retry_button_pressed() -> void:
	# back to the picker rather than straight into a run, so a new
	# character unlock can actually be used
	get_tree().change_scene_to_file("res://Scenes/character_select.tscn")

func _on_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/start_screen.tscn")
