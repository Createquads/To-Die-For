extends PanelContainer
# Balatro-style scoring readout, to the left of the tray.
#
# Walks the hand one die at a time after a roll, showing what each
# contributed and adding it to a running total. The point is not the
# final number -- the HUD already has that -- it is watching a mediocre
# hand turn into a big one when the jackpot line lands, so a player can
# feel their build getting stronger rather than being told.

signal walk_finished

const STEP_DELAY: float = 0.14   # gap between entries
const MAX_ROWS: int = 9          # a tall hand is trimmed rather than overflowing

@onready var rows: VBoxContainer = $Margin/VBox/Rows
@onready var total_label: Label = $Margin/VBox/Total
@onready var header: Label = $Margin/VBox/Header

var _running: float = 0.0
var _generation: int = 0

func _ready() -> void:
	Global.roll_resolved.connect(_on_roll_resolved)
	_clear()

func _clear() -> void:
	for child in rows.get_children():
		child.queue_free()
	_running = 0.0
	total_label.text = "$0.00"
	total_label.add_theme_color_override("font_color", Color(0.78, 0.72, 0.85))

func _on_roll_resolved(_faces, _gain, _loss, _log, steps) -> void:
	_generation += 1
	_walk(steps, _generation)

func _walk(steps: Array, gen: int) -> void:
	_clear()
	header.text = "THIS ROLL"
	# entries that moved no money are skipped -- a list of zeroes buries
	# the ones that matter
	var shown: Array = []
	for s in steps:
		if abs(float(s.get("amount", 0.0))) > 0.001 or s.get("note", "") != "":
			shown.append(s)
	if shown.size() > MAX_ROWS:
		shown = shown.slice(0, MAX_ROWS)
	if shown.is_empty():
		walk_finished.emit()
		return

	for s in shown:
		if gen != _generation:
			return   # another roll started; abandon this walk
		if not Settings.reduced_motion:
			await get_tree().create_timer(STEP_DELAY).timeout
			if gen != _generation or not is_instance_valid(self):
				return
		_add_row(s)
	# the round-end screen waits on this, so it never covers a total
	# that is still counting up
	if gen == _generation:
		walk_finished.emit()

func _add_row(s: Dictionary) -> void:
	var amount: float = float(s.get("amount", 0.0))
	_running += amount

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)

	var who := Label.new()
	who.text = _label_for(s)
	who.add_theme_font_size_override("font_size", 13)
	who.add_theme_color_override("font_color", _colour_for(s))
	who.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(who)

	var val := Label.new()
	val.text = "--" if abs(amount) < 0.001 else ("+$%.2f" % amount if amount > 0 else "-$%.2f" % -amount)
	val.add_theme_font_size_override("font_size", 13)
	val.add_theme_color_override("font_color",
		Color(0.55, 0.9, 0.6) if amount > 0 else (Color(0.9, 0.4, 0.4) if amount < 0 else Color(0.6, 0.56, 0.68)))
	row.add_child(val)
	rows.add_child(row)

	total_label.text = "$%.2f" % _running
	total_label.add_theme_color_override("font_color",
		Color(0.94, 0.83, 0.36) if _running >= 0 else Color(0.9, 0.4, 0.4))
	if not Settings.reduced_motion:
		_pop(total_label)

func _label_for(s: Dictionary) -> String:
	var kind: String = s.get("kind", "")
	if kind == "jackpot":
		return "JACKPOT  %s" % s.get("note", "")
	var name: String = Global.DIE_CATALOG.get(kind, {}).get("name", kind)
	var note: String = s.get("note", "")
	var face: int = int(s.get("face", 0))
	var head: String = "%s  [%d]" % [name, face] if face > 0 else name
	return head if note == "" else "%s  %s" % [head, note]

func _colour_for(s: Dictionary) -> Color:
	if s.get("kind", "") == "jackpot":
		return Color(0.94, 0.83, 0.36)
	return Color(0.84, 0.80, 0.90)

func _pop(node: Control) -> void:
	# a small punch on the total, so the eye follows it rather than the list
	node.pivot_offset = node.size * 0.5
	var t := create_tween()
	t.tween_property(node, "scale", Vector2(1.12, 1.12), 0.06)
	t.tween_property(node, "scale", Vector2.ONE, 0.10)
