extends Control
# Settings overlay, opened from the start screen. Every control writes
# through Settings.set_value(), which saves to disk and reapplies
# immediately -- so there's no "Apply" button to forget to press.

signal closed

@onready var master_slider: HSlider = $Panel/Margin/VBox/MasterRow/MasterSlider
@onready var master_value: Label = $Panel/Margin/VBox/MasterRow/MasterValue
@onready var sfx_slider: HSlider = $Panel/Margin/VBox/SfxRow/SfxSlider
@onready var sfx_value: Label = $Panel/Margin/VBox/SfxRow/SfxValue
@onready var fullscreen_check: CheckButton = $Panel/Margin/VBox/FullscreenCheck
@onready var motion_check: CheckButton = $Panel/Margin/VBox/MotionCheck
@onready var numbers_check: CheckButton = $Panel/Margin/VBox/NumbersCheck

func _ready() -> void:
	# runs while paused, since the pause menu opens it mid-run
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_pull_from_settings()

func open() -> void:
	# refresh from disk-backed values every time, in case anything
	# changed while this menu was closed
	_pull_from_settings()
	visible = true

func _pull_from_settings() -> void:
	master_slider.value = Settings.master_volume * 100.0
	sfx_slider.value = Settings.sfx_volume * 100.0
	fullscreen_check.button_pressed = Settings.fullscreen
	motion_check.button_pressed = Settings.reduced_motion
	numbers_check.button_pressed = Settings.show_die_numbers
	_update_value_labels()

func _update_value_labels() -> void:
	master_value.text = "%d%%" % int(master_slider.value)
	sfx_value.text = "%d%%" % int(sfx_slider.value)

func _on_master_slider_value_changed(value: float) -> void:
	Settings.set_value("master_volume", value / 100.0)
	_update_value_labels()

func _on_sfx_slider_value_changed(value: float) -> void:
	Settings.set_value("sfx_volume", value / 100.0)
	_update_value_labels()

func _on_fullscreen_check_toggled(pressed: bool) -> void:
	Settings.set_value("fullscreen", pressed)

func _on_motion_check_toggled(pressed: bool) -> void:
	Settings.set_value("reduced_motion", pressed)

func _on_numbers_check_toggled(pressed: bool) -> void:
	Settings.set_value("show_die_numbers", pressed)

func _on_back_button_pressed() -> void:
	visible = false
	closed.emit()
