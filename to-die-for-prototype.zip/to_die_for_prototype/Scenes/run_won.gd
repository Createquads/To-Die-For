extends Control
# Shown when a climb is completed -- the boss at the top of your tier
# is beaten and the run ends as a win rather than by running out of
# rolls. The summit moves ten rounds further out for next time, which
# is the whole reason a finished climb feels like progress.

@onready var summary: Label = $CenterContainer/Panel/VBox/Summary
@onready var next_up: Label = $CenterContainer/Panel/VBox/NextUp
@onready var title_label: Label = $CenterContainer/Panel/VBox/Title

func _ready() -> void:
	var cleared: int = Global.round_number
	var beaten: String = Global.BOSSES.get(Global.active_boss, {}).get("name", "the boss")
	summary.text = "You beat %s on round %d.\nFinal bank: $%.2f   Relics held: %d" % [
		beaten, cleared, Global.money, Global.owned_relics.size()
	]
	if Global.boss_tier > Global.MAX_BOSS_TIER - 1 and cleared >= Global.MAX_BOSS_TIER * Global.BOSS_INTERVAL:
		# the summit itself
		title_label.text = "THE HOUSE FOLDS"
		next_up.text = "Round 100. There is nothing above this.\nEvery climb from here is for the score alone."
	else:
		title_label.text = "CLIMB COMPLETE"
		next_up.text = "Next run climbs to round %d." % Global.target_round()

func _on_again_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/character_select.tscn")

func _on_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/start_screen.tscn")
