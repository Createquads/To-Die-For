extends CanvasLayer
# Unlock popup. Sits on the highest layer so it lands in front of the
# HUD, the shop and the tutorial, and shows the thing you just earned
# as an actual picture rather than a line of text scrolling past.
#
# Unlocks can fire several at once -- clearing a round can trip a die
# and a character together -- so they queue and are shown one at a time
# instead of overwriting each other.

signal closed

@onready var art_slot: CenterContainer = $Panel/Margin/VBox/ArtSlot
@onready var kicker: Label = $Panel/Margin/VBox/Kicker
@onready var title_label: Label = $Panel/Margin/VBox/Title
@onready var how_label: Label = $Panel/Margin/VBox/How
@onready var body_label: Label = $Panel/Margin/VBox/Body

var die_scene: PackedScene = load("res://Scenes/die.tscn")
var _queue: Array = []
var _showing: bool = false

func _ready() -> void:
	# has to run while paused: an unlock can land while the dice bag or
	# the pause menu has the tree frozen
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false

func queue_die(kind: String, die_name: String, objective: String) -> void:
	_queue.append({"type": "die", "kind": kind, "name": die_name, "objective": objective})
	_pump()

func queue_character(id: String, char_name: String, objective: String) -> void:
	_queue.append({"type": "character", "id": id, "name": char_name, "objective": objective})
	_pump()

func _pump() -> void:
	if _showing or _queue.is_empty():
		return
	_show(_queue.pop_front())

func _show(entry: Dictionary) -> void:
	_showing = true
	for child in art_slot.get_children():
		child.queue_free()

	if entry["type"] == "die":
		kicker.text = "NEW DIE UNLOCKED"
		kicker.add_theme_color_override("font_color", Color(0.55, 0.90, 0.60))
		body_label.text = Global.DIE_CATALOG.get(entry["kind"], {}).get("desc", "")
		art_slot.add_child(_big_die(entry["kind"]))
	else:
		kicker.text = "NEW PLAYER UNLOCKED"
		kicker.add_theme_color_override("font_color", Color(0.94, 0.83, 0.36))
		var info: Dictionary = Global.CHARACTERS.get(entry["id"], {})
		body_label.text = info.get("blurb", "")
		art_slot.add_child(_loadout_row(info.get("dice", {})))

	title_label.text = entry["name"]
	how_label.text = "Earned by: %s" % entry["objective"]
	visible = true

func _big_die(kind: String) -> Control:
	# shown large, so a die you've never drawn is recognisable the next
	# time it turns up in the shop
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(128, 128)
	var d = die_scene.instantiate()
	holder.add_child(d)
	d.setup(kind)
	d.make_preview(6)
	d.box = 128.0
	d.custom_minimum_size = Vector2(128, 128)
	d.size = Vector2(128, 128)
	d.pivot_offset = Vector2(64, 64)
	d.queue_redraw()
	return holder

func _loadout_row(dice: Dictionary) -> Control:
	# a character's opening bag, drawn rather than described
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var shown := 0
	for kind in dice.keys():
		for i in range(dice[kind]):
			if shown >= 6:
				break
			var d = die_scene.instantiate()
			row.add_child(d)
			d.setup(kind)
			d.make_preview(6)
			shown += 1
	return row

func _on_continue_button_pressed() -> void:
	_showing = false
	visible = false
	closed.emit()
	# straight into the next one if several landed together
	_pump()
