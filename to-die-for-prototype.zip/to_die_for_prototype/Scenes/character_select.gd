extends Control
# Character picker, shown after choosing a save slot. Scrolls through
# every character, locked ones included, so a player can always see
# what's still out there and what it costs -- same reasoning as the
# locked-dice list in the bag.

@export var main_scene: PackedScene = load("res://Scenes/main.tscn")

@onready var card_row: HBoxContainer = $VBox/Scroll/CardRow
@onready var start_button: Button = $VBox/Footer/StartButton
@onready var chosen_label: Label = $VBox/Footer/ChosenLabel
@onready var continue_button: Button = $VBox/ResumeRow/ContinueButton
@onready var resume_label: Label = $VBox/ResumeRow/ResumeLabel
@onready var tutorial_check: CheckButton = $VBox/ResumeRow/TutorialCheck

var die_scene: PackedScene = load("res://Scenes/die.tscn")
var _selected: String = "regular"

func _ready() -> void:
	# characters can open up from dice unlocked on the last run, so
	# re-check before drawing the list
	if Global.refresh_character_unlocks():
		Global.save_slot(Global.current_slot)
	_selected = Global.selected_character
	if not Global.unlocked_characters.has(_selected):
		_selected = "regular"
	_build()
	_refresh_resume()
	# reflects the saved preference, not whether the tutorial has run.
	# it used to derive from tutorial_done, so unticking never stuck --
	# the box came back ticked on the next visit
	tutorial_check.button_pressed = Global.tutorial_opt_in

func _build() -> void:
	for child in card_row.get_children():
		child.queue_free()
	for id in Global.CHARACTERS.keys():
		card_row.add_child(_make_card(id))
	_refresh_selection()

func _make_card(id: String) -> Control:
	# one card per character: name, starting dice as actual pictures,
	# and either the blurb or the objective that would unlock them
	var info: Dictionary = Global.CHARACTERS[id]
	var unlocked: bool = Global.unlocked_characters.has(id)

	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(250, 330)
	card.set_meta("id", id)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 12)
	margin.add_theme_constant_override("margin_top", 12)
	margin.add_theme_constant_override("margin_right", 12)
	margin.add_theme_constant_override("margin_bottom", 12)
	card.add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var title := Label.new()
	title.text = info["name"] if unlocked else "???"
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color",
		Color(0.94, 0.83, 0.36) if unlocked else Color(0.5, 0.46, 0.58))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)

	# the starting hand, drawn rather than described
	var dice_row := HBoxContainer.new()
	dice_row.alignment = BoxContainer.ALIGNMENT_CENTER
	dice_row.add_theme_constant_override("separation", 4)
	vbox.add_child(dice_row)
	var shown := 0
	for kind in info["dice"].keys():
		for i in range(info["dice"][kind]):
			if shown >= 6:
				break
			var icon = die_scene.instantiate()
			dice_row.add_child(icon)
			icon.setup(kind)
			icon.make_preview(6)
			if not unlocked:
				icon.modulate = Color(0.35, 0.33, 0.4)
			shown += 1

	var loadout := Label.new()
	loadout.text = _loadout_text(info)
	loadout.add_theme_font_size_override("font_size", 13)
	loadout.add_theme_color_override("font_color", Color(0.82, 0.76, 0.9))
	loadout.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	loadout.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox.add_child(loadout)

	var body := Label.new()
	body.text = info["blurb"] if unlocked else "LOCKED\n%s" % info["unlock"]
	body.add_theme_font_size_override("font_size", 13)
	body.add_theme_color_override("font_color",
		Color(0.75, 0.70, 0.83) if unlocked else Color(0.62, 0.56, 0.4))
	body.autowrap_mode = TextServer.AUTOWRAP_WORD
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(body)

	var pick := Button.new()
	pick.text = "Choose" if unlocked else "Locked"
	pick.disabled = not unlocked
	pick.pressed.connect(_on_card_pressed.bind(id))
	vbox.add_child(pick)

	return card

func _loadout_text(info: Dictionary) -> String:
	# "2x Glass Die, 4x Coin Die" plus any modifier the character carries
	var parts: Array = []
	for kind in info["dice"].keys():
		parts.append("%dx %s" % [info["dice"][kind], Global.DIE_CATALOG[kind]["name"]])
	var line: String = ", ".join(parts)
	if info.has("six_bonus"):
		line += "\n+%d%% per six" % int((info["six_bonus"] - 1.0) * 100.0)
	if info.has("rolls_bonus"):
		var r: int = info["rolls_bonus"]
		line += "\n%s%d rolls per round" % ["+" if r > 0 else "", r]
	return line

func _on_card_pressed(id: String) -> void:
	_selected = id
	_refresh_selection()

func _refresh_selection() -> void:
	# highlight the chosen card by tinting the others down
	for card in card_row.get_children():
		card.modulate = Color.WHITE if card.get_meta("id") == _selected else Color(0.72, 0.72, 0.78)
	chosen_label.text = "Playing as: %s" % Global.CHARACTERS[_selected]["name"]

func _on_start_button_pressed() -> void:
	Global.selected_character = _selected
	Global.tutorial_opt_in = tutorial_check.button_pressed
	Global.tutorial_requested = tutorial_check.button_pressed
	if tutorial_check.button_pressed:
		Global.tutorial_done = false
	Global.save_slot(Global.current_slot)
	get_tree().change_scene_to_packed(main_scene)

func _on_back_button_pressed() -> void:
	# by path -- save_select preloads this scene, so preloading it back
	# would be a cycle
	get_tree().change_scene_to_file("res://Scenes/save_select.tscn")

func _refresh_resume() -> void:
	# a suspended run is offered here rather than on the title screen,
	# because this is the one place a NEW run can be started -- so the
	# choice between the two sits in front of the player together
	var data: Dictionary = Global.suspended_run_summary()
	var has_run: bool = not data.is_empty()
	continue_button.visible = has_run
	resume_label.visible = has_run
	if not has_run:
		start_button.text = "Start Run"
		return
	var who: String = String(data.get("character", "regular"))
	var char_name: String = Global.CHARACTERS.get(who, {}).get("name", "someone")
	resume_label.text = "Run in progress: %s on round %d" % [char_name, int(data.get("round_number", 1))]
	# spelled out, because starting fresh throws the saved run away
	start_button.text = "Start New Run (ends the one above)"

func _on_continue_button_pressed() -> void:
	# resuming never replays the tutorial
	Global.tutorial_requested = false
	Global.resume_pending = true
	get_tree().change_scene_to_packed(main_scene)
