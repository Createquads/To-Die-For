extends Control
# Title screen -- the project's main scene, so it's what boots first.
# It never touches run state: Start goes to the save-slot picker, and
# the run itself begins in main.tscn.

@export var save_select_scene: PackedScene = load("res://Scenes/save_select.tscn")

@onready var settings_menu = $SettingsMenu
@onready var starfield: TextureRect = $Starfield

func _ready() -> void:
	Settings.settings_changed.connect(_apply_motion)
	_apply_motion()

func _apply_motion() -> void:
	# the twinkle is a sine, so switching it off just freezes the sky at
	# its neutral brightness rather than snapping to a different look
	starfield.material.set_shader_parameter("enabled", 0.0 if Settings.reduced_motion else 1.0)

func _on_start_button_pressed() -> void:
	get_tree().change_scene_to_packed(save_select_scene)

func _on_settings_button_pressed() -> void:
	settings_menu.open()

func _on_quit_button_pressed() -> void:
	get_tree().quit()
