extends CanvasLayer
# First-run tutorial. It doesn't fake a round -- it guides the player
# through their real first one, so nothing has to be re-learned once it
# ends. Two steps wait on an actual action (rolling, opening the bag);
# the rest advance on Next. Skip is always available.
#
# The dimmer cuts a hole around whatever is being explained and passes
# clicks straight through, so the player can still press Roll and open
# the bag while it's up.
#
# It's a CanvasLayer above the HUD rather than a plain Control: the HUD
# is itself a CanvasLayer, so a Control dimmer would have been drawn
# underneath it and the bank and target could never have been dimmed.

signal finished

@onready var dimmer: Control = $Dimmer
@onready var panel: PanelContainer = $Panel
@onready var body: Label = $Panel/Margin/VBox/Body
@onready var step_label: Label = $Panel/Margin/VBox/Header/StepLabel
@onready var next_button: Button = $Panel/Margin/VBox/Buttons/NextButton
@onready var skip_button: Button = $Panel/Margin/VBox/Buttons/SkipButton

# text, what to spotlight, and whether the step waits on the player.
# "wait" steps disable Next until the action happens, which is what
# stops the tutorial being a wall of text you click through blind.
const STEPS := [
	{"text": "Every round you draw a handful of dice and roll them, over and over, chasing sixes.\n\nThis is a real round -- nothing here is pretend. Let's walk through it.",
	 "focus": "", "wait": ""},
	{"text": "This is your hand for the round, drawn at random from your dice bag.\n\nYou start with six plain dice, so right now every one of them is an ordinary six-sided die.",
	 "focus": "hand", "wait": ""},
	{"text": "Only two faces matter.\n\nA 6 pays you. A 1 costs you three quarters of what a 6 pays. Everything in between does nothing at all.",
	 "focus": "hand", "wait": ""},
	{"text": "This is the round's target, and how close you are to it.\n\nReach it and the round is cleared. That progress resets every round.",
	 "focus": "target", "wait": ""},
	{"text": "Your bank is separate, and it does NOT reset.\n\nIt's what you spend in the shop between rounds. Spending it can never undo the round progress you've made -- so buy freely.",
	 "focus": "bank", "wait": ""},
	{"text": "You get a limited number of rolls to hit the target.\n\nRun out before you reach it and the run is over. That's the whole tension.",
	 "focus": "rolls", "wait": ""},
	{"text": "Go on -- press Roll.",
	 "focus": "roll", "wait": "roll"},
	{"text": "That's the loop.\n\nLand two or more 6s in the same hand and they pay a jackpot multiplier together, so a big hand is worth far more than the same sixes spread out.",
	 "focus": "log", "wait": ""},
	{"text": "Last thing. Click the bag at the bottom.",
	 "focus": "bag", "wait": "bag"},
	{"text": "Everything you own lives in there, along with every die you haven't unlocked yet and what it takes to earn it.\n\nClear the target to reach the shop, and buy more dice. Good luck.",
	 "focus": "bag", "wait": ""},
]

var _step: int = 0
var _focus_rect: Rect2 = Rect2()
var _targets: Dictionary = {}
var _waiting_for: String = ""

func _ready() -> void:
	# runs while paused, because opening the dice bag pauses the tree
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false

func begin(targets: Dictionary) -> void:
	# targets maps a focus key to the Control it should spotlight
	_targets = targets
	_step = 0
	visible = true
	_show_step()

func _on_action(kind: String) -> void:
	# main.gd forwards the two actions a step can wait on
	if _waiting_for != "" and _waiting_for == kind:
		_waiting_for = ""
		next_button.disabled = false
		next_button.text = "Next"
		_advance()

func _show_step() -> void:
	if _step >= STEPS.size():
		_finish()
		return
	var s: Dictionary = STEPS[_step]
	body.text = s["text"]
	step_label.text = "Tutorial  %d / %d" % [_step + 1, STEPS.size()]

	_waiting_for = s["wait"]
	next_button.disabled = _waiting_for != ""
	if _waiting_for == "roll":
		next_button.text = "Waiting for your roll..."
	elif _waiting_for == "bag":
		next_button.text = "Waiting..."
	else:
		next_button.text = "Next" if _step < STEPS.size() - 1 else "Start playing"

	_focus_rect = _rect_for(s["focus"])
	_place_panel()
	dimmer.queue_redraw()

func _rect_for(key: String) -> Rect2:
	if key == "" or not _targets.has(key):
		return Rect2()
	var node = _targets[key]
	if node == null or not is_instance_valid(node):
		return Rect2()
	var r: Rect2 = node.get_global_rect()
	return r.grow(10.0)

func _place_panel() -> void:
	# keep the panel off whatever it's pointing at, and on screen
	var view: Vector2 = get_viewport().get_visible_rect().size
	var w: float = panel.size.x if panel.size.x > 0 else 460.0
	var h: float = panel.size.y if panel.size.y > 0 else 200.0
	var x: float = (view.x - w) * 0.5
	var y: float = view.y - h - 40.0
	if _focus_rect.size != Vector2.ZERO and _focus_rect.position.y > view.y * 0.55:
		y = 90.0   # focus is low on screen, so sit the panel up top
	panel.position = Vector2(clampf(x, 12.0, max(view.x - w - 12.0, 12.0)),
		clampf(y, 12.0, max(view.y - h - 12.0, 12.0)))

func _advance() -> void:
	_step += 1
	_show_step()

func _on_next_button_pressed() -> void:
	_advance()

func _on_skip_button_pressed() -> void:
	_finish()

func _finish() -> void:
	visible = false
	_waiting_for = ""
	finished.emit()

func _on_dimmer_draw() -> void:
	# a full-screen dim with a hole cut around the focus. drawn as four
	# rects rather than with a shader, which keeps it cheap and exact
	var view: Vector2 = get_viewport().get_visible_rect().size
	var shade := Color(0, 0, 0, 0.62)
	if _focus_rect.size == Vector2.ZERO:
		dimmer.draw_rect(Rect2(Vector2.ZERO, view), shade)
		return
	var f: Rect2 = _focus_rect
	dimmer.draw_rect(Rect2(0, 0, view.x, f.position.y), shade)
	dimmer.draw_rect(Rect2(0, f.position.y + f.size.y, view.x, view.y - f.position.y - f.size.y), shade)
	dimmer.draw_rect(Rect2(0, f.position.y, f.position.x, f.size.y), shade)
	dimmer.draw_rect(Rect2(f.position.x + f.size.x, f.position.y,
		view.x - f.position.x - f.size.x, f.size.y), shade)
	# a gold frame around the hole, so the eye lands on it immediately
	dimmer.draw_rect(f, Color(0.94, 0.83, 0.36), false, 2.0)
