extends CanvasLayer
# Top status bar: round, spendable bank, progress toward this round's
# target, and rolls left. Pure display -- it only reads Global and
# reacts to its signals.
# The bank and the round progress are shown separately on purpose:
# the bank is what you can spend in the shop, while the progress bar
# is what actually clears the round, and spending never undoes it.

@onready var round_label: Label = $Bar/HBoxContainer/RoundLabel
@onready var money_label: Label = $Bar/HBoxContainer/MoneyLabel
@onready var threshold_label: Label = $Bar/HBoxContainer/ThresholdLabel
@onready var rolls_label: Label = $Bar/HBoxContainer/RollsLabel
@onready var boss_label: Label = $Bar/HBoxContainer/BossLabel
@onready var progress: ProgressBar = $Progress

var _bar_tween: Tween = null

func _ready() -> void:
	Global.money_changed.connect(_on_money_changed)
	Global.rolls_changed.connect(_on_rolls_changed)
	Global.round_advanced.connect(_on_round_advanced)
	Global.earnings_changed.connect(_on_earnings_changed)
	# paint once up front so the bar isn't blank before the first signal
	_on_money_changed(Global.money)
	_on_rolls_changed(Global.rolls_remaining)
	_on_round_advanced(Global.round_number, Global.round_threshold)
	_on_earnings_changed(Global.round_earnings, Global.round_threshold)

func _on_money_changed(new_money) -> void:
	money_label.text = "Bank: $%.2f" % new_money

func _on_rolls_changed(rolls_left) -> void:
	rolls_label.text = "Rolls left: %d" % rolls_left
	# turn the counter red once you're running out of room
	var colour: Color = Color(0.85, 0.78, 0.9) if rolls_left > 5 else Color(0.9, 0.35, 0.35)
	rolls_label.add_theme_color_override("font_color", colour)

func _on_round_advanced(new_round, new_threshold) -> void:
	# the summit is always on screen, so the climb has a visible end
	round_label.text = "Round %d / %d" % [new_round, Global.target_round()]
	# bosses recolour the round counter so there's no missing one
	var boss: bool = Global.active_boss != ""
	round_label.add_theme_color_override("font_color",
		Color(1, 0.45, 0.45) if boss else Color(0.94, 0.83, 0.36))
	boss_label.text = "BOSS" if boss else ""
	_on_earnings_changed(Global.round_earnings, new_threshold)

func _on_earnings_changed(earned, target) -> void:
	# progress toward clearing the round, which is separate from the bank.
	# the bar counts to the new figure over one roll cooldown rather than
	# snapping, so gains and losses are both legible as they happen
	threshold_label.text = "This round: $%.2f / $%.2f" % [earned, target]
	progress.max_value = target
	var goal: float = min(earned, target)
	if Settings.reduced_motion:
		progress.value = goal
		return
	if _bar_tween != null and _bar_tween.is_valid():
		_bar_tween.kill()
	_bar_tween = create_tween()
	_bar_tween.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	_bar_tween.tween_property(progress, "value", goal, Global.ROLL_COOLDOWN * 0.9)

func focus_node(key: String) -> Control:
	# lets the tutorial spotlight a specific readout without reaching
	# into this scene's node paths from outside
	match key:
		"bank": return money_label
		"target": return threshold_label
		"rolls": return rolls_label
		"progress": return progress
		"round": return round_label
	return null
