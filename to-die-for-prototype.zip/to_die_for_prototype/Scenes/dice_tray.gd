extends TextureRect
# The hand-drawn dice tray. Owns the dice, the roll button and the
# result log, all anchored inside the artwork: the big felt panel holds
# the dice, and the two carved-out corner brackets show the HAND and
# BAG counts so no part of the drawing goes unused.
#
# The dice sit in a plain Control rather than an HBoxContainer, because
# a container overwrites any position you set -- and the throw needs
# free positioning. The row is laid out by hand instead, which is also
# what guarantees the dice never spill past the felt.

var die_scene: PackedScene = load("res://Scenes/die.tscn")

# --- throw timings. these add up to just under ROLL_COOLDOWN, so the
# dice have always settled before the next roll is allowed ---
const STAGGER: float = 0.03      # gap between each die leaving the hand
const FLIGHT: float = 0.30       # airborne time
const HOLD: float = 0.12         # beat where they sit where they landed
const LINEUP: float = 0.24       # sliding into the row
const DIE_PX: float = 64.0       # mirrors Die.SIZE
const GAP: float = 6.0
# A tilted square reaches further than its own width: at the landing
# tilt a 64px die sticks out about 9px past its axis-aligned box, so
# the scatter area is inset by this much to keep corners on the felt.
const TILT_MARGIN: float = 10.0
# The felt's right edge sits almost exactly where MainZone ends, so the
# playable width is pulled in to stop dice sitting on the wooden frame.
const EDGE_INSET_RIGHT: float = 34.0
const EDGE_INSET_LEFT: float = 6.0

@onready var dice_field: Control = $MainZone/VBox/DiceField
@onready var roll_button: Button = $MainZone/VBox/RollButton
@onready var log_label: Label = $MainZone/VBox/LogLabel
@onready var hand_count: Label = $HandZone/VBox/Count
@onready var bag_count: Label = $BagZone/VBox/Count
@onready var cooldown: Timer = $Cooldown

var _locked_by_overlay: bool = false
# bumped whenever the hand changes, so a throw that's still mid-flight
# knows to abandon itself instead of touching freed dice
var _generation: int = 0
# set when a die broke or wore out this roll. The field is not rebuilt
# until the throw has finished, so the shattered die stays on screen
# long enough to be seen breaking.
var _pending_prune: bool = false

func _ready() -> void:
	Global.hand_drawn.connect(_on_hand_drawn)
	Global.hand_pruned.connect(_on_hand_pruned)
	Global.roll_resolved.connect(_on_roll_resolved)
	Global.bag_changed.connect(_on_bag_changed)
	dice_field.resized.connect(_layout_row)
	_on_hand_drawn(Global.current_hand)
	_on_bag_changed(Global.dice_bag)

# ===================================================================
# roll button
# ===================================================================

func set_rolling_enabled(enabled: bool) -> void:
	# main.gd calls this to lock the button while an overlay is up.
	# tracked separately from the cooldown so the two can't unlock
	# each other by accident
	_locked_by_overlay = not enabled
	_refresh_roll_button()

func _refresh_roll_button() -> void:
	var cooling: bool = not cooldown.is_stopped()
	roll_button.disabled = _locked_by_overlay or cooling
	roll_button.text = "..." if cooling else "ROLL"

func _on_roll_button_pressed() -> void:
	# a short lockout after each roll, so the button can't be spammed
	# and the throw has time to finish before the next one starts
	Global.roll_hand()
	cooldown.wait_time = Global.ROLL_COOLDOWN
	cooldown.start()
	_refresh_roll_button()

func _on_cooldown_timeout() -> void:
	_refresh_roll_button()

# ===================================================================
# building and placing the dice
# ===================================================================

func _on_hand_drawn(hand) -> void:
	# rebuild the dice to match the newly drawn hand, resting in a row
	_generation += 1
	for child in dice_field.get_children():
		child.queue_free()
	for die in hand:
		var visual = die_scene.instantiate()
		dice_field.add_child(visual)
		visual.setup(die.active_kind())
		visual.size = Vector2(DIE_PX, DIE_PX)
	hand_count.text = str(hand.size())
	_layout_row()

func _row_positions(count: int) -> Array:
	# Evenly spaced and centred, with the step shrunk if the dice would
	# otherwise run past the felt. Because step is capped at
	# (width - DIE_PX) / (count - 1), the row is mathematically
	# guaranteed to fit inside the field no matter how many dice a
	# Feather-heavy bag draws.
	var out: Array = []
	if count <= 0:
		return out
	var h: float = max(dice_field.size.y, DIE_PX)
	var w: float = _usable_width()
	var step: float = DIE_PX + GAP
	if count > 1:
		step = min(step, (w - DIE_PX) / float(count - 1))
	var row_w: float = DIE_PX + step * float(count - 1)
	# centred within the inset area, not the whole field
	var start_x: float = EDGE_INSET_LEFT + (w - row_w) * 0.5
	var y: float = (h - DIE_PX) * 0.5
	for i in range(count):
		out.append(Vector2(start_x + step * float(i), y))
	return out

func _usable_width() -> float:
	# how much of the field is actually green felt
	return max(dice_field.size.x - EDGE_INSET_LEFT - EDGE_INSET_RIGHT, DIE_PX)

func _layout_row() -> void:
	# snap everything to its resting place, no animation
	var kids := dice_field.get_children()
	var spots: Array = _row_positions(kids.size())
	for i in range(kids.size()):
		kids[i].position = spots[i]
		kids[i].rotation = 0.0

func _scatter_spot(_w: float, h: float) -> Vector2:
	# a random landing spot, inset so that even a die sitting at the
	# full landing tilt keeps all four corners on the felt
	var w: float = _usable_width()
	var span_x: float = max(w - DIE_PX - TILT_MARGIN * 2.0, 0.0)
	var span_y: float = max(h - DIE_PX - TILT_MARGIN * 2.0, 0.0)
	return Vector2(
		EDGE_INSET_LEFT + TILT_MARGIN + randf_range(0.0, span_x),
		TILT_MARGIN + randf_range(0.0, span_y)
	)

# ===================================================================
# the throw
# ===================================================================

func _on_roll_resolved(faces, _gain, _loss, log_line, _steps) -> void:
	# The hand is still whole at this point, so faces line up one to one
	# with the dice on screen. Rebuilding here is what used to kill the
	# throw whenever a Glass Die shattered.
	log_label.text = log_line
	var broken: Array = []
	for die in Global.current_hand:
		broken.append(die.broken or die.exhausted)
	_throw(faces, broken)

func _on_hand_pruned(hand) -> void:
	# Something broke or wore out. Note it and deal with it once the
	# dice have landed, rather than yanking them off mid-flight.
	# Under reduced motion there is no flight to protect, and this
	# signal arrives after _throw() has already returned, so the
	# rebuild has to happen here or it would never happen at all.
	hand_count.text = str(hand.size())
	if Settings.reduced_motion:
		_on_hand_drawn(hand)
		return
	_pending_prune = true

func _throw(faces, broken: Array = []) -> void:
	var kids := dice_field.get_children()
	if kids.is_empty():
		return

	# reduced motion gets the result with no flight at all
	if Settings.reduced_motion:
		_layout_row()
		for i in range(kids.size()):
			if i < faces.size():
				kids[i].show_face(faces[i], i < broken.size() and broken[i])
		return

	_generation += 1
	var gen: int = _generation
	var w: float = max(dice_field.size.x, DIE_PX)
	var h: float = max(dice_field.size.y, DIE_PX)

	for i in range(kids.size()):
		var die = kids[i]
		# thrown in from off the top of the tray, from a random spot
		# along the edge, so no two rolls look quite the same
		die.position = Vector2(randf_range(-DIE_PX, w), -h - DIE_PX)
		# The spin comes from the sheet's tumble frames now, not from
		# rotating the node. Rotating as well looked like two separate
		# spins fighting, and it meant every die had to be unwound to
		# straight at line-up.
		die.rotation = 0.0
		die.start_tumble()

		var target: Vector2 = _scatter_spot(w, h)
		var delay: float = float(i) * STAGGER

		var t := create_tween()
		# BACK easing gives a little settle-bounce as it hits the felt
		t.tween_property(die, "position", target, FLIGHT).set_delay(delay) \
			.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		# the face is only revealed on impact, so the result reads as
		# the outcome of the throw rather than something already decided
		t.tween_callback(_reveal.bind(die, faces[i] if i < faces.size() else 1, gen,
			i < broken.size() and broken[i]))

	await get_tree().create_timer(STAGGER * float(kids.size() - 1) + FLIGHT + HOLD).timeout
	# the hand may have been rebuilt while these were in the air
	if gen != _generation or not is_instance_valid(dice_field):
		return

	var spots: Array = _row_positions(kids.size())
	for i in range(kids.size()):
		var die = kids[i]
		if not is_instance_valid(die):
			continue
		var t := create_tween()
		t.tween_property(die, "position", spots[i], LINEUP) \
			.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)

	# once the row has formed, drop whatever broke and close the gap
	await get_tree().create_timer(LINEUP).timeout
	if gen != _generation or not is_instance_valid(dice_field):
		return
	if _pending_prune:
		_pending_prune = false
		_on_hand_drawn(Global.current_hand)

func _reveal(die, face: int, gen: int, is_broken: bool = false) -> void:
	# called the instant a die touches down. a shattered die lands too,
	# showing its break, instead of vanishing before it is ever seen
	if gen != _generation or not is_instance_valid(die):
		return
	die.show_face(face, is_broken)

func _on_bag_changed(bag) -> void:
	bag_count.text = str(bag.size())

func focus_node(key: String) -> Control:
	match key:
		"hand": return dice_field
		"roll": return roll_button
		"log": return log_label
	return null
