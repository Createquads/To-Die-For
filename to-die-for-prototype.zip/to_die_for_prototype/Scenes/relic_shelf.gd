extends Control
# The relics you own, laid out in a grid beside the tray, the way
# Binding of Isaac keeps your items on screen.
#
# Held at half opacity so it reads as a reminder rather than competing
# with the dice, and brightens on hover with the full description --
# glanceable at rest, readable when you actually want it.

const COLS: int = 4
const ICON: float = 44.0
const ICON_CELL: float = 128.0
const ICON_COLS: int = 8
const RESTING_ALPHA: float = 0.5

@onready var grid: GridContainer = $VBox/Grid
@onready var caption: Label = $VBox/Caption

var sheet: Texture2D = preload("res://assets/relic_icons.png")

func _ready() -> void:
	grid.columns = COLS
	Global.relics_changed.connect(_rebuild)
	_rebuild(Global.owned_relics)

func _rebuild(relics) -> void:
	for child in grid.get_children():
		child.queue_free()
	caption.text = "" if relics.is_empty() else "%d relic%s" % [relics.size(), "" if relics.size() == 1 else "s"]
	for id in relics:
		grid.add_child(_make_icon(id))

func _make_icon(id: String) -> Control:
	var info: Dictionary = Global.RELICS[id]
	var index: int = int(info.get("icon", 0))

	var atlas := AtlasTexture.new()
	atlas.atlas = sheet
	atlas.region = Rect2(float(index % ICON_COLS) * ICON_CELL,
		float(index / ICON_COLS) * ICON_CELL, ICON_CELL, ICON_CELL)

	var tex := TextureRect.new()
	tex.texture = atlas
	tex.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	tex.custom_minimum_size = Vector2(ICON, ICON)
	tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tex.modulate.a = RESTING_ALPHA
	# the name alone says nothing about the effect, so the tooltip
	# carries the full description
	tex.tooltip_text = "%s\n%s" % [info["name"], info["desc"]]
	tex.mouse_filter = Control.MOUSE_FILTER_STOP
	tex.mouse_entered.connect(_on_hover.bind(tex, info, true))
	tex.mouse_exited.connect(_on_hover.bind(tex, info, false))
	return tex

func _on_hover(tex: TextureRect, info: Dictionary, entered: bool) -> void:
	tex.modulate.a = 1.0 if entered else RESTING_ALPHA
	if entered:
		caption.text = info["name"]
	else:
		var n: int = Global.owned_relics.size()
		caption.text = "" if n == 0 else "%d relic%s" % [n, "" if n == 1 else "s"]
