extends Control
# Between-round shop, split down the middle: relics on the left,
# dice on the right.
#
# The two halves answer different questions. Dice change what you draw;
# relics change the rules those dice play by. Keeping them side by side
# rather than mixed in one list is what lets a player steer a build --
# you can see both levers at once and decide which one this round's
# money should go on.

signal shop_closed
signal wants_picker(item_id, item_name, need)

const ICON_CELL: float = 128.0
const ICON_COLS: int = 8

@onready var offer_box: VBoxContainer = $Panel/Margin/VBox/Columns/DiceSide/DiceOffers
@onready var relic_box: VBoxContainer = $Panel/Margin/VBox/Columns/RelicSide/RelicOffers
@onready var subtitle: Label = $Panel/Margin/VBox/Subtitle
@onready var dice_reroll: Button = $Panel/Margin/VBox/Columns/DiceSide/DiceReroll
@onready var relic_reroll: Button = $Panel/Margin/VBox/Columns/RelicSide/RelicReroll

var relic_sheet: Texture2D = preload("res://assets/relic_icons.png")

func _ready() -> void:
	visible = false

func open(die_offers, relic_offers) -> void:
	_populate(die_offers, relic_offers)
	visible = true

func _populate(die_offers, relic_offers) -> void:
	_update_subtitle()
	_fill_dice(die_offers)
	_fill_relics(relic_offers)
	_refresh_reroll()

func _fill_dice(offers) -> void:
	for child in offer_box.get_children():
		child.queue_free()
	for id in offers:
		offer_box.add_child(_make_offer_button(id))

func _fill_relics(offers) -> void:
	for child in relic_box.get_children():
		child.queue_free()
	for id in offers:
		relic_box.add_child(_make_relic_button(id))
	if offers.is_empty():
		var none := Label.new()
		none.text = "Nothing left to covet."
		none.add_theme_color_override("font_color", Color(0.6, 0.56, 0.68))
		none.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		relic_box.add_child(none)

# --- dice side -------------------------------------------------------

func _make_offer_button(id: String) -> Button:
	# offers can be dice or items, so the lookup goes through
	# Global.offer_info() rather than the die catalog directly
	var info: Dictionary = Global.offer_info(id)
	var cost: float = Global.die_price(id)
	var btn := Button.new()
	var tag: String = "[ITEM] " if Global.is_item(id) else ""
	# the panel is wide enough now that a description fits on one or two
	# lines, so nothing has to be scrolled to be read
	btn.text = "%s%s  --  $%.2f\n%s" % [tag, info["name"], cost, info["desc"]]
	# tall enough for a three-line description at column width, so the
	# longest entry in the catalog still fits without a scrollbar
	btn.custom_minimum_size = Vector2(0, 86)
	btn.autowrap_mode = TextServer.AUTOWRAP_WORD
	btn.disabled = not Global.can_buy(id)
	btn.set_meta("id", id)
	btn.set_meta("bought", false)
	btn.pressed.connect(_on_offer_pressed.bind(btn))
	return btn

func _on_offer_pressed(btn: Button) -> void:
	var id: String = btn.get_meta("id")
	var bought: bool = Global.buy_item(id) if Global.is_item(id) else Global.buy_die(id)
	if not bought:
		return
	btn.set_meta("bought", true)
	btn.disabled = true
	btn.text += "\n(done)" if Global.is_item(id) else "\n(in the bag)"
	_update_subtitle()
	_refresh_affordability()
	# some items are paid for here but only take effect once the player
	# has chosen which dice to scrap
	var need: int = Global.item_needs_choice(id)
	if need > 0:
		wants_picker.emit(id, Global.offer_info(id)["name"], need)

# --- relic side ------------------------------------------------------

func _make_relic_button(id: String) -> Button:
	# icon, name, tier and effect. The icon matters more here than on
	# the dice side: a relic's name says nothing about what it does, so
	# the emblem is what a player learns to recognise across runs.
	var info: Dictionary = Global.RELICS[id]
	var btn := Button.new()
	btn.custom_minimum_size = Vector2(0, 104)
	btn.disabled = not Global.can_buy_relic(id)
	btn.set_meta("id", id)
	btn.set_meta("bought", false)
	btn.pressed.connect(_on_relic_pressed.bind(btn))

	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.set_anchors_preset(Control.PRESET_FULL_RECT)
	row.add_theme_constant_override("separation", 10)
	btn.add_child(row)

	var pad := Control.new()
	pad.custom_minimum_size = Vector2(8, 0)
	row.add_child(pad)
	row.add_child(_relic_icon(info.get("icon", 0), 56))

	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	col.add_theme_constant_override("separation", 1)
	row.add_child(col)

	var head := Label.new()
	head.text = "%s  --  $%.2f" % [info["name"], Global.relic_price(id)]
	head.add_theme_font_size_override("font_size", 15)
	head.add_theme_color_override("font_color", _tier_colour(info["tier"]))
	col.add_child(head)

	var body := Label.new()
	body.text = info["desc"]
	body.add_theme_font_size_override("font_size", 12)
	body.add_theme_color_override("font_color", Color(0.84, 0.80, 0.90))
	body.autowrap_mode = TextServer.AUTOWRAP_WORD
	body.custom_minimum_size = Vector2(300, 0)
	col.add_child(body)
	return btn

func _relic_icon(index: int, px: float) -> TextureRect:
	# one cell out of the emblem sheet
	var atlas := AtlasTexture.new()
	atlas.atlas = relic_sheet
	atlas.region = Rect2(float(index % ICON_COLS) * ICON_CELL,
		float(index / ICON_COLS) * ICON_CELL, ICON_CELL, ICON_CELL)
	var tex := TextureRect.new()
	tex.texture = atlas
	tex.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	tex.custom_minimum_size = Vector2(px, px)
	tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return tex

func _tier_colour(tier: String) -> Color:
	match tier:
		"mythic": return Color(0.86, 0.55, 0.98)
		"rare":   return Color(0.94, 0.83, 0.36)
	return Color(0.74, 0.80, 0.92)

func _on_relic_pressed(btn: Button) -> void:
	if not Global.buy_relic(btn.get_meta("id")):
		return
	btn.set_meta("bought", true)
	btn.disabled = true
	_update_subtitle()
	_refresh_affordability()

# --- shared ----------------------------------------------------------

func _refresh_affordability() -> void:
	# after a purchase, grey out whatever you can no longer pay for and
	# re-enable anything you still can
	for child in offer_box.get_children():
		if child is Button and not child.get_meta("bought", false):
			child.disabled = not Global.can_buy(child.get_meta("id"))
	for child in relic_box.get_children():
		if child is Button and not child.get_meta("bought", false):
			child.disabled = not Global.can_buy_relic(child.get_meta("id"))
	_refresh_reroll()

func _update_subtitle() -> void:
	subtitle.text = "Bank: $%.2f  --  spending never costs you round progress." % Global.money

func _refresh_reroll() -> void:
	# each side prices independently, so spinning for a relic doesn't
	# make the dice more expensive
	_set_reroll(dice_reroll, "dice")
	_set_reroll(relic_reroll, "relics")

func _set_reroll(btn: Button, side: String) -> void:
	var cost: float = Global.reroll_cost(side)
	btn.text = "Reroll  --  FREE" if cost <= 0.0 else "Reroll  --  $%.2f" % cost
	btn.disabled = not Global.can_reroll(side)

func _on_dice_reroll_pressed() -> void:
	var fresh: Array = Global.reroll_dice_offers()
	if not fresh.is_empty():
		_fill_dice(fresh)
		_update_subtitle()
		_refresh_affordability()

func _on_relic_reroll_pressed() -> void:
	var fresh: Array = Global.reroll_relic_offers()
	if not fresh.is_empty():
		_fill_relics(fresh)
		_update_subtitle()
		_refresh_affordability()

func refresh_after_picker() -> void:
	_update_subtitle()
	_refresh_affordability()

func _on_continue_button_pressed() -> void:
	visible = false
	shop_closed.emit()
