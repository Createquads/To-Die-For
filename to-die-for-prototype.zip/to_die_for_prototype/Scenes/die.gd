extends Control
# A single die. Draws itself from the sprite sheet rather than by hand:
# row 0 of the sheet holds the six three-quarter faces, row 1 holds the
# 8-frame tumble loop used while a die is in the air.
#
# There are 27 die kinds but only four sheet palettes, so each kind
# picks the palette closest to its character and then a per-kind
# modulate separates it from its neighbours. That keeps every kind
# visually distinct without needing 27 hand-drawn sheets.

const SHEET_CELL: float = 256.0   # source cell size on the sheet
const SIZE: float = 64.0          # drawn size on the tray (exact 2:1)
const PREVIEW_SIZE: float = 32.0  # icon size in lists (exact 4:1)
const BIG_FACE_SCALE: float = 1.25
const TUMBLE_FRAMES: int = 8
const TUMBLE_FPS: float = 14.0

const SHEETS := {
	"ivory": preload("res://assets/dice_sheet.png"),
	"crimson": preload("res://assets/dice_sheet_crimson.png"),
	"violet": preload("res://assets/dice_sheet_violet.png"),
	"jade": preload("res://assets/dice_sheet_jade.png"),
}

# kind -> [sheet palette, modulate tint]
# Palettes are grouped by what a die does, so the colour carries meaning:
# ivory for plain and mechanical dice, crimson for risk and breakage,
# violet for copying and jackpot tricks, jade for protection and income.
const KIND_STYLE := {
	"base":        ["ivory", Color(1.00, 1.00, 1.00)],
	"glass":       ["ivory", Color(0.62, 0.90, 1.00)],
	"bone":        ["ivory", Color(0.94, 0.90, 0.76)],
	"ivory":       ["ivory", Color(1.00, 0.98, 0.90)],
	"sable":       ["ivory", Color(0.42, 0.40, 0.48)],
	"rusted":      ["ivory", Color(0.80, 0.52, 0.34)],
	"clockwork":   ["ivory", Color(0.90, 0.82, 0.58)],
	"chisel":      ["ivory", Color(0.72, 0.75, 0.80)],
	"gilded":      ["ivory", Color(1.00, 0.80, 0.25)],
	"tithe":       ["ivory", Color(0.78, 0.72, 0.48)],

	"cracked":     ["crimson", Color(1.00, 1.00, 1.00)],
	"coin":        ["crimson", Color(1.10, 0.95, 0.60)],
	"ashen":       ["crimson", Color(0.72, 0.66, 0.66)],
	"snake_eyes":  ["crimson", Color(1.00, 0.85, 0.85)],

	"mirror":      ["violet", Color(1.00, 1.00, 1.00)],
	"echo":        ["violet", Color(0.86, 0.92, 1.05)],
	"twin":        ["violet", Color(0.92, 0.86, 1.00)],
	"prism":       ["violet", Color(1.05, 0.88, 1.05)],
	"hollow":      ["violet", Color(0.62, 0.60, 0.70)],
	"grafted":     ["violet", Color(0.86, 0.96, 0.92)],
	"mimic":       ["violet", Color(1.05, 0.80, 0.95)],

	"lucky_charm": ["jade", Color(1.00, 1.00, 1.00)],
	"serpent":     ["jade", Color(0.88, 1.05, 0.80)],
	"anchor":      ["jade", Color(0.72, 0.86, 0.95)],
	"warden":      ["jade", Color(0.70, 0.88, 1.05)],
	"loaded":      ["jade", Color(1.05, 0.98, 0.62)],
	"feather":     ["jade", Color(0.92, 1.02, 1.00)],
}

var face_value: int = 1
var kind: String = "base"
var is_broken: bool = false
var box: float = SIZE
var _tween: Tween = null
var _tumbling: bool = false
var _tumble_time: float = 0.0

func _ready() -> void:
	# nearest filtering, and the drawn sizes are exact divisors of the
	# 128px source cell, so the pixels stay square rather than smeared
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	custom_minimum_size = Vector2(box, box)
	pivot_offset = Vector2(box, box) * 0.5
	set_process(false)
	Settings.settings_changed.connect(queue_redraw)

func setup(die_kind: String) -> void:
	kind = die_kind
	queue_redraw()

func make_preview(face: int = 6) -> void:
	# shrinks this die into a static icon for the lists, so a player can
	# see what a die looks like before they ever draw one
	box = PREVIEW_SIZE
	face_value = face
	_tumbling = false
	set_process(false)
	custom_minimum_size = Vector2(box, box)
	size = Vector2(box, box)
	pivot_offset = Vector2(box, box) * 0.5
	queue_redraw()

func start_tumble() -> void:
	# cycles the sheet's tumble row while the die is airborne
	_tumbling = true
	_tumble_time = randf() * float(TUMBLE_FRAMES)
	set_process(true)
	queue_redraw()

func _process(delta: float) -> void:
	_tumble_time += delta * TUMBLE_FPS
	queue_redraw()

func show_face(value: int, broken: bool = false) -> void:
	# called the moment a die lands: stops the tumble, shows the result,
	# and pops 6s and 1s -- the only faces that do anything -- to 1.25x
	face_value = value
	is_broken = broken
	_tumbling = false
	set_process(false)
	queue_redraw()
	_scale_to(BIG_FACE_SCALE if (value == 6 or value == 1) else 1.0)

func _scale_to(target: float) -> void:
	# scale rather than resize, so growing a die never reflows the row
	pivot_offset = Vector2(box, box) * 0.5
	if Settings.reduced_motion:
		scale = Vector2(target, target)
		return
	if _tween != null and _tween.is_valid():
		_tween.kill()
	_tween = create_tween()
	_tween.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_tween.tween_property(self, "scale", Vector2(target, target), 0.18)

func _style() -> Array:
	return KIND_STYLE.get(kind, KIND_STYLE["base"])

func _draw() -> void:
	var style: Array = _style()
	var tex: Texture2D = SHEETS[style[0]]
	var tint: Color = style[1]

	var col: int = 0
	var row: int = 0
	if _tumbling:
		row = 1
		col = int(_tumble_time) % TUMBLE_FRAMES
	else:
		col = clampi(face_value - 1, 0, 5)

	if is_broken:
		# drained of colour, so a shattered die reads as spent
		tint = Color(0.40, 0.40, 0.44, 0.65)

	var src := Rect2(float(col) * SHEET_CELL, float(row) * SHEET_CELL, SHEET_CELL, SHEET_CELL)
	draw_texture_rect_region(tex, Rect2(Vector2.ZERO, Vector2(box, box)), src, tint)

	if is_broken:
		draw_line(Vector2(box * 0.2, box * 0.2), Vector2(box * 0.8, box * 0.8), Color.RED, 2.0)
		draw_line(Vector2(box * 0.8, box * 0.2), Vector2(box * 0.2, box * 0.8), Color.RED, 2.0)
		return

	if Settings.show_die_numbers and not _tumbling:
		_draw_numeral()

func _draw_numeral() -> void:
	# the accessibility option can't recolour baked-in pips, so it lays a
	# numeral over the die instead -- outlined, to stay legible on any tint
	var font := ThemeDB.fallback_font
	var fsize: int = int(box * 0.42)
	var text := str(face_value)
	var w: float = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fsize).x
	var at := Vector2((box - w) * 0.5, box * 0.52 + fsize * 0.36)
	for ox in [-1, 1]:
		for oy in [-1, 1]:
			draw_string(font, at + Vector2(ox, oy), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fsize, Color.BLACK)
	draw_string(font, at, text, HORIZONTAL_ALIGNMENT_LEFT, -1, fsize, Color.WHITE)
