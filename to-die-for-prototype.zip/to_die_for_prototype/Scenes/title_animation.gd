extends Control
# Looping title-screen background: a shrouded dealer with dice turning
# above his upturned palms.
#
# The dice are real Die instances running the sprite sheet's tumble row,
# so the spin here is exactly the spin in-game rather than a separate
# animation that could drift out of step.
#
# Colour drifts through every kind in the game. Because kinds sit on
# four different sheet palettes, switching would otherwise be a hard
# cut, so each die crossfades: the outgoing kind fades out while the
# incoming one fades in over the same beat.

# Measured off the artwork itself by locating the skin-toned blobs, so
# these track the real hands rather than being guessed. The figure is
# not symmetric in its own frame -- the right hand reaches further --
# which is why these two are not mirrored.
const PALM_L := Vector2(0.087, 0.748)
const PALM_R := Vector2(0.824, 0.748)
const HOVER_ABOVE: float = 0.20       # how far above the palm, as a fraction of height
const DIE_PX: float = 60.0
const BOB_HEIGHT: float = 7.0
const BOB_SECONDS: float = 2.6
const HOLD_SECONDS: float = 2.2       # how long a colour sits before drifting on
const FADE_SECONDS: float = 0.9

@onready var dealer: TextureRect = $Dealer

var die_scene: PackedScene = load("res://Scenes/die.tscn")
var _slots: Array = []      # each: {out, incoming, anchor, phase, timer, order}
var _kinds: Array = []

func _ready() -> void:
	# every die in the game, so the drift eventually shows all of them
	_kinds = Global.DIE_CATALOG.keys()
	_kinds.shuffle()
	_build()
	dealer.resized.connect(_reposition)
	resized.connect(_reposition)

func _build() -> void:
	# One die over each palm. A third riding between them looked good in
	# isolation but landed on top of the menu, and the palms are where
	# the dice belong anyway. Offset phases so the two don't bob in
	# lockstep, which reads as mechanical.
	var anchors := [
		{"at": PALM_L, "lift": 0.0, "phase": 0.0},
		{"at": PALM_R, "lift": 0.0, "phase": 1.3},
	]
	for i in range(anchors.size()):
		var a: Dictionary = anchors[i]
		var slot := {
			"anchor": a["at"], "lift": a["lift"], "phase": a["phase"],
			"order": i, "timer": float(i) * 0.8,
			"outgoing": _make_die(_kind_at(i)),
			"incoming": _make_die(_kind_at(i + anchors.size())),
			"fading": false, "t": 0.0,
		}
		slot["incoming"].modulate.a = 0.0
		_slots.append(slot)

func _make_die(kind: String):
	var d = die_scene.instantiate()
	add_child(d)
	d.setup(kind)
	d.box = DIE_PX
	d.custom_minimum_size = Vector2(DIE_PX, DIE_PX)
	d.size = Vector2(DIE_PX, DIE_PX)
	d.pivot_offset = Vector2(DIE_PX, DIE_PX) * 0.5
	d.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# a constantly spinning die is exactly what reduced motion is for,
	# so it rests on a face instead -- the colour drift still plays,
	# since a slow crossfade is not the part that causes trouble
	if Settings.reduced_motion:
		d.show_face(6)
	else:
		d.start_tumble()
	return d

func _kind_at(i: int) -> String:
	return _kinds[i % _kinds.size()]

func _process(delta: float) -> void:
	for slot in _slots:
		_advance(slot, delta)
	_reposition()

func _advance(slot: Dictionary, delta: float) -> void:
	slot["timer"] += delta
	if not slot["fading"] and slot["timer"] >= HOLD_SECONDS:
		slot["fading"] = true
		slot["t"] = 0.0
	if not slot["fading"]:
		return

	slot["t"] += delta
	var k: float = clampf(slot["t"] / FADE_SECONDS, 0.0, 1.0)
	slot["outgoing"].modulate.a = 1.0 - k
	slot["incoming"].modulate.a = k

	if k < 1.0:
		return
	# swap roles and queue the next kind in the cycle
	slot["outgoing"].queue_free()
	slot["outgoing"] = slot["incoming"]
	slot["outgoing"].modulate.a = 1.0
	slot["order"] = int(slot["order"]) + _slots.size()
	slot["incoming"] = _make_die(_kind_at(int(slot["order"]) + _slots.size()))
	slot["incoming"].modulate.a = 0.0
	slot["fading"] = false
	slot["timer"] = 0.0

func _reposition() -> void:
	# anchored to the dealer's own rect, so the dice stay over the palms
	# whatever size the art ends up being on screen
	var r: Rect2 = dealer.get_rect()
	var t: float = float(Time.get_ticks_msec()) / 1000.0
	for slot in _slots:
		var a: Vector2 = slot["anchor"]
		var bob: float = 0.0
		if not Settings.reduced_motion:
			bob = sin((t + float(slot["phase"])) * TAU / BOB_SECONDS) * BOB_HEIGHT
		var centre := Vector2(
			r.position.x + r.size.x * a.x,
			r.position.y + r.size.y * (a.y - HOVER_ABOVE - float(slot["lift"])) + bob
		)
		var at: Vector2 = centre - Vector2(DIE_PX, DIE_PX) * 0.5
		slot["outgoing"].position = at
		slot["incoming"].position = at
