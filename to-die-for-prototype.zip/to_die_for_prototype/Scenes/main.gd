extends Control
# The game screen. Deliberately thin: it starts the run, wires the
# child scenes together, and handles transitions. All the rules live
# in Global and all the drawing lives in the child scenes.

@onready var dice_tray = $DiceTray
@onready var shop = $Shop
@onready var toast: Label = $Toast
@onready var toast_timer: Timer = $ToastTimer
@onready var boss_banner: PanelContainer = $BossBanner
@onready var boss_name: Label = $BossBanner/Margin/VBox/BossName
@onready var boss_desc: Label = $BossBanner/Margin/VBox/BossDesc
@onready var end_delay: Timer = $ShopDelay
@onready var dice_bag = $DiceBag
@onready var pause_menu = $PauseMenu
@onready var hud = $HUD
@onready var tutorial = $Tutorial
@onready var unlock_popup = $UnlockPopup
@onready var dice_picker = $DicePicker
@onready var score_readout = $ScoreReadout

var _picker_item: String = ""
# what should take over once the scoring walk finishes: "", "shop",
# "won" or "lost"
var _pending_end: String = ""

const END_SCREEN_DELAY: float = 2.5

var _pending_offers: Array = []

func _ready() -> void:
	# either pick up a suspended run or start a fresh one -- the
	# character screen decides which by setting resume_pending
	if Global.resume_pending and Global.resume_run():
		Global.resume_pending = false
	else:
		Global.resume_pending = false
		Global.start_new_run()

	Global.shop_opened.connect(_on_shop_opened)
	Global.run_ended.connect(_on_run_ended)
	Global.run_won.connect(_on_run_won)
	score_readout.walk_finished.connect(_on_walk_finished)
	Global.achievement_unlocked.connect(_on_achievement_unlocked)
	Global.die_unlocked.connect(_on_die_unlocked)
	Global.boss_started.connect(_on_boss_started)
	Global.round_advanced.connect(_on_round_advanced)
	shop.shop_closed.connect(_on_shop_closed)
	shop.wants_picker.connect(_on_wants_picker)
	dice_picker.picked.connect(_on_picker_picked)
	dice_picker.cancelled.connect(_on_picker_cancelled)
	Global.character_unlocked.connect(_on_character_unlocked)
	pause_menu.resumed.connect(_on_pause_closed)

	toast.visible = false
	boss_banner.visible = false
	tutorial.finished.connect(_on_tutorial_finished)
	# deferred, so containers have finished laying out. the tutorial
	# measures on-screen rects to place its spotlight, and during
	# _ready those are still at their pre-layout sizes
	call_deferred("_maybe_start_tutorial")
	if Global.active_boss != "":
		_on_boss_started(Global.active_boss,
			Global.BOSSES[Global.active_boss]["name"],
			Global.BOSSES[Global.active_boss]["desc"])

func _maybe_start_tutorial() -> void:
	# only on a fresh run of a profile that has not seen it, and never
	# on a resumed run -- nobody wants the basics re-explained mid-climb
	if Global.resume_pending or Global.tutorial_done:
		return
	if not Global.tutorial_requested:
		return
	tutorial.begin({
		"hand": dice_tray.focus_node("hand"),
		"roll": dice_tray.focus_node("roll"),
		"log": dice_tray.focus_node("log"),
		"bank": hud.focus_node("bank"),
		"target": hud.focus_node("target"),
		"rolls": hud.focus_node("rolls"),
		"bag": dice_bag.focus_node("bag"),
	})
	Global.roll_resolved.connect(_on_tutorial_roll)
	dice_bag.opened.connect(_on_tutorial_bag)

func _on_tutorial_roll(_f, _g, _l, _line, _steps) -> void:
	tutorial._on_action("roll")

func _on_tutorial_bag() -> void:
	tutorial._on_action("bag")

func _on_tutorial_finished() -> void:
	# marked done whether it was completed or skipped, so it never
	# reappears uninvited
	# finishing OR skipping switches the checkbox off for next time --
	# it stays on screen, so it can be turned back on deliberately
	Global.tutorial_done = true
	Global.tutorial_opt_in = false
	Global.tutorial_requested = false
	Global.save_slot(Global.current_slot)
	if Global.roll_resolved.is_connected(_on_tutorial_roll):
		Global.roll_resolved.disconnect(_on_tutorial_roll)
	if dice_bag.opened.is_connected(_on_tutorial_bag):
		dice_bag.opened.disconnect(_on_tutorial_bag)

func _unhandled_input(event: InputEvent) -> void:
	# one owner for Escape: close the bag if it's up, otherwise toggle
	# the pause menu. having both nodes listen would race
	if not event.is_action_pressed("ui_cancel"):
		return
	if tutorial.visible and dice_bag.is_open():
		dice_bag.close()
	elif dice_bag.is_open():
		dice_bag.close()
	elif pause_menu.is_open():
		pause_menu.close()
	else:
		# the HUD is a CanvasLayer, so it draws above the pause blur --
		# hiding it keeps the pause screen clean
		hud.visible = false
		pause_menu.open()
	get_viewport().set_input_as_handled()

func _on_pause_closed() -> void:
	hud.visible = true

func _on_walk_finished() -> void:
	# The scoring walk has stopped counting. Anything that takes over
	# the screen waits for this and then a further beat, so the player
	# sees the final total rather than having it snatched away.
	if _pending_end == "":
		return
	end_delay.wait_time = END_SCREEN_DELAY
	end_delay.start()

func _on_end_delay_timeout() -> void:
	var what: String = _pending_end
	_pending_end = ""
	if what == "shop":
		shop.open(_pending_offers[0], _pending_offers[1])
	elif what == "won":
		get_tree().change_scene_to_file("res://Scenes/run_won.tscn")
	elif what == "lost":
		get_tree().change_scene_to_file("res://Scenes/game_over.tscn")

func _on_shop_opened(die_offers, relic_offers) -> void:
	# hold for a beat before the shop covers the tray, so the hand that
	# actually cleared the round is still readable and the progress bar
	# has time to finish counting up to the target
	dice_tray.set_rolling_enabled(false)
	_pending_offers = [die_offers, relic_offers]
	_pending_end = "shop"

func _on_shop_closed() -> void:
	Global.advance_round()
	dice_tray.set_rolling_enabled(true)

func _on_round_advanced(_new_round, _new_threshold) -> void:
	# the banner only belongs on boss rounds, so clear it otherwise.
	# boss_started fires straight after this and re-shows it when due
	if Global.active_boss == "":
		boss_banner.visible = false

func _on_boss_started(_id, name_text, desc_text) -> void:
	boss_name.text = "BOSS ROUND -- %s" % name_text
	boss_desc.text = desc_text
	boss_banner.visible = true

func _on_run_ended(_final_round) -> void:
	dice_tray.set_rolling_enabled(false)
	_pending_end = "lost"

func _on_run_won(_final_round, _new_tier, _is_final) -> void:
	dice_tray.set_rolling_enabled(false)
	_pending_end = "won"

func _on_achievement_unlocked(_id, title) -> void:
	_show_toast("Achievement -- %s" % title, Color(0.94, 0.83, 0.36))

func _on_die_unlocked(kind, die_name, objective) -> void:
	# a full popup rather than a toast: a new die is the reward that
	# actually changes the next run, so it's worth stopping to look at
	unlock_popup.queue_die(kind, die_name, objective)

func _on_character_unlocked(id, char_name, objective) -> void:
	unlock_popup.queue_character(id, char_name, objective)

func _on_wants_picker(item_id, item_name, need) -> void:
	_picker_item = item_id
	dice_picker.open(item_name, need)

func _on_picker_picked(indices) -> void:
	Global.apply_removal(_picker_item, indices)
	_picker_item = ""
	shop.refresh_after_picker()

func _on_picker_cancelled() -> void:
	_picker_item = ""
	shop.refresh_after_picker()

func _show_toast(text: String, colour: Color) -> void:
	toast.text = text
	toast.add_theme_color_override("font_color", colour)
	toast.visible = true
	toast_timer.start()

func _on_toast_timer_timeout() -> void:
	toast.visible = false
