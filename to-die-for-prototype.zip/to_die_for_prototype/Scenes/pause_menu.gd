extends Control
# In-run pause menu. Opening it freezes the tree and blurs the game
# behind, the same treatment the dice bag gets.
# Both exits park the run on disk first, so it can be picked back up
# from the character screen exactly where it was left -- the only thing
# that discards it is starting a new run, or going bust.

signal resumed

@onready var blur: ColorRect = $Blur
@onready var panel: PanelContainer = $Panel
@onready var settings_menu = $SettingsMenu

func _ready() -> void:
	# has to keep running while paused, or it would freeze itself shut
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	settings_menu.closed.connect(_on_settings_closed)

func is_open() -> bool:
	return visible

func open() -> void:
	visible = true
	panel.visible = true
	settings_menu.visible = false
	get_tree().paused = true

func close() -> void:
	visible = false
	get_tree().paused = false
	resumed.emit()

func _on_continue_button_pressed() -> void:
	close()

func _on_settings_button_pressed() -> void:
	# swap the pause panel for the settings overlay, staying paused
	panel.visible = false
	settings_menu.open()

func _on_settings_closed() -> void:
	panel.visible = true

func _on_character_button_pressed() -> void:
	_leave("res://Scenes/character_select.tscn")

func _on_menu_button_pressed() -> void:
	_leave("res://Scenes/start_screen.tscn")

func _leave(scene_path: String) -> void:
	# unpause before switching, otherwise the next scene loads frozen
	Global.suspend_run()
	get_tree().paused = false
	get_tree().change_scene_to_file(scene_path)
