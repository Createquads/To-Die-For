extends Control
# Save-slot picker, shown after Start. Three slots, each showing what
# that profile has earned so far. Picking one makes it the active slot
# and drops straight into a fresh run.

@export var character_scene: PackedScene = load("res://Scenes/character_select.tscn")

@onready var slot_box: VBoxContainer = $CenterContainer/VBox/SlotBox

func _ready() -> void:
	_rebuild_slots()

func _rebuild_slots() -> void:
	# one card per slot: a big Play button plus a small Erase button
	for child in slot_box.get_children():
		child.queue_free()

	for slot in range(1, Global.SAVE_SLOTS + 1):
		var summary: Dictionary = Global.slot_summary(slot)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)

		var play := Button.new()
		play.custom_minimum_size = Vector2(440, 72)
		play.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		play.text = _slot_label(slot, summary)
		play.pressed.connect(_on_slot_pressed.bind(slot))
		row.add_child(play)

		var erase := Button.new()
		erase.custom_minimum_size = Vector2(90, 72)
		erase.text = "Erase"
		erase.disabled = summary.get("empty", true)
		erase.pressed.connect(_on_erase_pressed.bind(slot))
		row.add_child(erase)

		slot_box.add_child(row)

func _slot_label(slot: int, summary: Dictionary) -> String:
	# empty slots invite a new run; used ones show what's been earned
	if summary.get("empty", true):
		return "Slot %d\nEmpty -- start a new profile" % slot
	return "Slot %d\nBest: Round %d   Runs: %d   Achievements: %d   Dice unlocked: %d" % [
		slot, summary["best_round"], summary["runs_played"],
		summary["achievements"], summary["dice_unlocked"],
	]

func _on_slot_pressed(slot: int) -> void:
	# load the profile, then pick who's playing it
	Global.load_slot(slot)
	get_tree().change_scene_to_packed(character_scene)

func _on_erase_pressed(slot: int) -> void:
	Global.delete_slot(slot)
	_rebuild_slots()

func _on_back_button_pressed() -> void:
	# by path, not a preloaded scene: start_screen already points here,
	# and two scenes preloading each other is a dependency cycle
	get_tree().change_scene_to_file("res://Scenes/start_screen.tscn")
