extends RefCounted
class_name DieData
# One die that lives in your bag. Holds its kind, whatever per-run
# state that kind accumulates (Ivory's growing payout, Ashen's six
# counter, Clockwork's position in its cycle, Grafted's absorbed
# power), and knows how to roll its own face.
# Pure data + logic, no visuals -- Scenes/die.tscn draws one of these.

const LUCKY_CHARM_CHARGES: int = 8   # rolls a Lucky Charm lasts, counting only its own

var kind: String = "base"
var value_multiplier: float = 1.0    # flat payout scaling for this kind
var penalty_multiplier: float = 1.0  # flat penalty scaling for this kind
var broken: bool = false             # Glass shattered / Ashen burnt out
var exhausted: bool = false          # Lucky Charm ran out of charges
var charges_left: int = -1           # -1 means "never wears out"

# per-kind running state
var ivory_sixes: int = 0             # Ivory: +5% payout per six it has rolled
var sixes_rolled: int = 0            # Ashen: shatters on its third six
var clock_index: int = 0             # Clockwork: position in the 1..6 cycle
var rounds_survived: int = 0         # Rusted: +2% six chance per round
var graft_count: int = 0             # Grafted: power absorbed from shattered Glass
var mimic_kind: String = ""          # Mimic: whichever kind it copied this round

func _init(p_kind: String = "base") -> void:
	# assign per-kind starting stats; anything not listed keeps defaults
	kind = p_kind
	match kind:
		"cracked":
			value_multiplier = 2.0
			penalty_multiplier = 2.0
		"gilded":
			value_multiplier = 3.0
		"ashen":
			value_multiplier = 4.0
		"lucky_charm":
			charges_left = LUCKY_CHARM_CHARGES

func active_kind() -> String:
	# Mimic behaves as whatever it copied this round; everything else
	# is just itself. Every rule in global.gd asks through here so
	# Mimic automatically inherits the copied die's whole behaviour.
	if kind == "mimic" and mimic_kind != "":
		return mimic_kind
	return kind

func payout_multiplier() -> float:
	# flat kind multiplier plus whatever this individual die has earned
	return value_multiplier * (1.0 + 0.05 * ivory_sixes)

func on_round_start(bag_kinds: Array, round_number: int) -> void:
	# Mimic re-rolls what it's copying, Rusted ages one round
	rounds_survived = round_number
	if kind == "mimic":
		var options: Array = []
		for k in bag_kinds:
			if k != "mimic":
				options.append(k)
		mimic_kind = options[randi() % options.size()] if options.size() > 0 else ""

func on_rolled() -> void:
	# Called exactly once per die per hand, from phase 1 in global.gd.
	# The countdown used to live inside roll_face(), which is also called
	# by Bone's bonus reroll -- and a Mimic copying Lucky Charm started
	# at -1 charges, so it burnt out on its very first roll. Counting
	# here means a charm only ever spends its OWN rolls.
	if active_kind() != "lucky_charm":
		return
	if charges_left < 0:
		charges_left = LUCKY_CHARM_CHARGES  # lazy init, so Mimic copies get a full set
	charges_left -= 1
	if charges_left <= 0:
		exhausted = true

func on_six() -> void:
	# bookkeeping for the dice that care how often they've hit
	sixes_rolled += 1
	if active_kind() == "ivory":
		ivory_sixes += 1
	if active_kind() == "ashen" and sixes_rolled >= 3:
		broken = true

func on_glass_shattered() -> void:
	# Grafted absorbs the power of any Glass Die that breaks
	if active_kind() == "grafted":
		graft_count += 1

func roll_face(ctx: Dictionary) -> int:
	# roll a single face 1-6 using this die's own odds. ctx carries the
	# hand-wide facts some kinds need: the base probabilities, how many
	# Basic Dice are in the bag (Sable), and the round number (Rusted).
	# The Mirror Match boss switches every special off, so a die rolls
	# as a plain Basic for that round -- checked here so the odds and
	# the hand-wide tricks in global.gd both honour it
	var k: String = "base" if ctx.get("specials_off", false) else active_kind()
	var probs: Dictionary = ctx["probs"].duplicate()

	match k:
		"glass":
			# a d20 painted 19x six, 1x one -- collapsed to a weighted
			# coin flip since only "six vs one" ever matters here
			return 6 if randf() < 19.0 / 20.0 else 1
		"coin":
			# two faces only, dead even
			return 6 if randf() < 0.5 else 1
		"clockwork":
			# strictly 1,2,3,4,5,6 and around again -- no randomness at
			# all, so a six is guaranteed every sixth roll (and so is a one)
			clock_index = (clock_index + 1) % 6
			return clock_index + 1
		"twin":
			# rolls itself twice and keeps the better face
			return max(_weighted_face(probs), _weighted_face(probs))
		"anchor":
			# cannot roll a 1 -- that weight goes to the middle faces --
			# and pays for it with slightly worse six odds
			probs[6] = max(probs[6] - 0.03, 0.0)
			var spare: float = probs[1] + 0.03
			probs[1] = 0.0
			for f in [2, 3, 4, 5]:
				probs[f] += spare / 4.0
		"loaded":
			probs[6] = min(probs[6] + 0.10, 0.9)
		"lucky_charm":
			probs[6] = min(probs[6] + 0.15, 0.9)
		"tithe":
			# pays a fee every roll (charged in global.gd) for 1-in-3 sixes
			probs[6] = 1.0 / 3.0
		"rusted":
			# starts weak and improves every round survived. tuned up from
			# its first pass, where it was strictly worse than a Basic Die
			probs[6] = min(0.05 + 0.03 * rounds_survived, 0.6)
		"sable":
			# thrives on a fat bag -- better odds the more Basic Dice you keep
			probs[6] = min(probs[6] + 0.02 * int(ctx.get("base_count", 0)), 0.7)
		"grafted":
			# each Glass Die that shattered made this one sharper
			probs[6] = min(probs[6] + 0.15 * graft_count, 0.9)

	return _weighted_face(probs)

func _weighted_face(probs: Dictionary) -> int:
	# pick a face from a {face: probability} dictionary, renormalised so
	# the kinds above can add or remove weight without the total drifting
	var total := 0.0
	for f in [1, 2, 3, 4, 5, 6]:
		total += max(probs.get(f, 0.0), 0.0)
	if total <= 0.0:
		return 6
	var roll := randf() * total
	var cumulative := 0.0
	for f in [1, 2, 3, 4, 5, 6]:
		cumulative += max(probs.get(f, 0.0), 0.0)
		if roll < cumulative:
			return f
	return 6

# --- serialisation -------------------------------------------------
# Used when a run is suspended so it can be picked up later in exactly
# the state it was left in, accumulated per-die state included.

func to_dict() -> Dictionary:
	return {
		"kind": kind,
		"value_multiplier": value_multiplier,
		"penalty_multiplier": penalty_multiplier,
		"broken": broken,
		"exhausted": exhausted,
		"charges_left": charges_left,
		"ivory_sixes": ivory_sixes,
		"sixes_rolled": sixes_rolled,
		"clock_index": clock_index,
		"rounds_survived": rounds_survived,
		"graft_count": graft_count,
		"mimic_kind": mimic_kind,
	}

static func from_dict(data: Dictionary) -> DieData:
	# _init sets the per-kind defaults, then the saved values overwrite
	# them, so a die reloads with whatever it had earned
	var die := DieData.new(String(data.get("kind", "base")))
	die.value_multiplier = float(data.get("value_multiplier", die.value_multiplier))
	die.penalty_multiplier = float(data.get("penalty_multiplier", die.penalty_multiplier))
	die.broken = bool(data.get("broken", false))
	die.exhausted = bool(data.get("exhausted", false))
	die.charges_left = int(data.get("charges_left", die.charges_left))
	die.ivory_sixes = int(data.get("ivory_sixes", 0))
	die.sixes_rolled = int(data.get("sixes_rolled", 0))
	die.clock_index = int(data.get("clock_index", 0))
	die.rounds_survived = int(data.get("rounds_survived", 0))
	die.graft_count = int(data.get("graft_count", 0))
	die.mimic_kind = String(data.get("mimic_kind", ""))
	return die
