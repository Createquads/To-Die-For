extends Node
# Global run state -- the single source of truth. Owns the dice bag,
# the current hand, round/boss progression, the shop, lifetime stats,
# and which dice have been unlocked. Scenes read this and listen to
# its signals; they never write to its vars directly.

signal money_changed(new_money)
signal earnings_changed(earned, target)
signal rolls_changed(rolls_left)
signal round_advanced(new_round, new_threshold)
signal hand_drawn(hand)
signal hand_pruned(hand)
signal roll_resolved(faces, gain, loss, log_line, steps)
signal shop_opened(die_offers, relic_offers)
signal relics_changed(relics)
signal bag_changed(bag)
signal run_ended(final_round)
signal run_won(final_round, new_tier, is_final)
signal achievement_unlocked(id, title)
signal die_unlocked(kind, die_name, objective)
signal character_unlocked(id, char_name, objective)
signal boss_started(boss_id, boss_name, boss_desc)

# --- tunables ------------------------------------------------------
const VALUE_PER_SIX: float = 1.0
const ONE_PENALTY_RATIO: float = 0.75
const MULTI_SIX_FACTOR: float = 1.5
const ROUND_ROLL_BUDGET: int = 22
const ROUND_THRESHOLD_BASE: float = 8.0
# Steepened from 1.10. With the climb now ending at a fixed summit
# rather than running forever, the curve can be tuned against a target:
# at 1.125 round 100 asks about $1.39M, which is roughly two thirds of
# what a near-perfect build can earn in a round. Demanding, but not
# luck-locked. Above ~1.13 the summit is arithmetically impossible.
const ROUND_THRESHOLD_GROWTH: float = 1.125
const BASE_BAG_SIZE: int = 6
const HAND_SIZE: int = 6
const MAX_BAG_SIZE: int = 20
const BONE_BONUS_CHANCE: float = 0.25
const TITHE_FEE_RATIO: float = 0.35
const SNAKE_EYES_PAYOUT: float = 6.0
const MAX_FEATHER_SLOTS: int = 3
const ROLL_COOLDOWN: float = 1.0        # seconds the Roll button stays locked after a roll
const BOSS_INTERVAL: int = 10           # every Nth round is a boss
const MAX_BOSS_TIER: int = 10           # tier 10 = round 100, the summit
const BOSS_THRESHOLD_SCALE: float = 1.5 # bosses ask for more on top of the normal curve
const SHOP_OFFERS: int = 3
const SHOP_OFFERS_AFTER_BOSS: int = 4   # beating a boss widens the next shop
# Rerolling is the economy's main sink. Without one, money piles up
# faster than there is anything to spend it on, and the shop stops
# being a decision. The cost climbs steeply within a visit and resets
# on leaving, so it's a burst of spending rather than a tax.
const REROLL_BASE_FRACTION: float = 0.25   # of the threshold just cleared
const REROLL_GROWTH: float = 1.75          # per reroll within one visit

# How often each tier turns up. Top-tier dice are deliberately scarce,
# which is what gives rerolling something to chase.
const TIER_WEIGHT := {
	"basic": 6.0,
	"mid": 2.5,
	"top": 1.0,
}

const TIER_PRICE_FRACTION := {
	"basic": 1.0 / 6.0,
	"mid": 1.0 / 3.0,
	"top": 1.0 / 2.0,
}

# --- die catalog ---------------------------------------------------
const DIE_CATALOG := {
	"base":        {"name": "Basic Die",       "tier": "basic", "desc": "A plain, fair six-sided die. Just another shot at a six."},

	"cracked":     {"name": "Cracked Die",     "tier": "mid",   "desc": "Doubles its own payout AND its own penalty."},
	"lucky_charm": {"name": "Lucky Charm Die", "tier": "mid",   "desc": "Great odds, but wears out and vanishes after 8 rolls."},
	"loaded":      {"name": "Loaded Die",      "tier": "mid",   "desc": "Better-than-fair odds, but never joins the multi-six jackpot."},
	"anchor":      {"name": "Anchor Die",      "tier": "mid",   "desc": "Can never roll a 1. Pays for it with slightly worse six odds."},
	"echo":        {"name": "Echo Die",        "tier": "mid",   "desc": "Copies the face of the die to its left in the hand."},
	"ivory":       {"name": "Ivory Die",       "tier": "mid",   "desc": "Every 6 it rolls permanently raises its own payout by 5%."},
	"rusted":      {"name": "Rusted Die",      "tier": "mid",   "desc": "Starts weak. Gains +3% six chance every round you survive."},
	"serpent":     {"name": "Serpent Die",     "tier": "mid",   "desc": "When it rolls a 1, it turns the next die's face into a 6."},
	"tithe":       {"name": "Tithe Die",       "tier": "mid",   "desc": "Charges a fee every roll, but hits a 6 one time in three."},
	"chisel":      {"name": "Chisel Die",      "tier": "mid",   "desc": "Its 1s cost you nothing -- they pull a Basic Die out of your bag instead."},
	"mimic":       {"name": "Mimic Die",       "tier": "mid",   "desc": "Becomes a copy of a random other die in your bag each round."},
	"clockwork":   {"name": "Clockwork Die",   "tier": "mid",   "desc": "No randomness at all: cycles 1-2-3-4-5-6, so every sixth roll is a guaranteed 6."},
	"ashen":       {"name": "Ashen Die",       "tier": "mid",   "desc": "Every 6 pays quadruple, but it burns out after its third one."},
	"sable":       {"name": "Sable Die",       "tier": "mid",   "desc": "Gets better odds the more Basic Dice you keep in your bag."},
	"grafted":     {"name": "Grafted Die",     "tier": "mid",   "desc": "Permanently sharpens every time one of your Glass Dice shatters."},

	"glass":       {"name": "Glass Die",       "tier": "top",   "desc": "19/20 chance of a 6. The 1 shatters it and costs 10x the penalty."},
	"bone":        {"name": "Bone Die",        "tier": "top",   "desc": "Normal odds, but a rolled 6 can win a free bonus reroll."},
	"mirror":      {"name": "Mirror Die",      "tier": "top",   "desc": "Rolls no face of its own -- copies the best face you rolled."},
	"twin":        {"name": "Twin Die",        "tier": "top",   "desc": "Rolls itself twice and keeps the higher face."},
	"gilded":      {"name": "Gilded Die",      "tier": "top",   "desc": "Its 6s pay triple, but only join the jackpot when 3+ sixes land."},
	"hollow":      {"name": "Hollow Die",      "tier": "top",   "desc": "Pays nothing itself -- its 6 doubles the jackpot multiplier for the whole hand."},
	"prism":       {"name": "Prism Die",       "tier": "top",   "desc": "When 3+ sixes land, it adds a phantom extra six to the jackpot."},
	"feather":     {"name": "Feather Die",     "tier": "top",   "desc": "Doesn't count against your hand size -- you draw an extra die every round."},
	"coin":        {"name": "Coin Die",        "tier": "top",   "desc": "Two faces only: 6 or 1, dead even."},
	"warden":      {"name": "Warden Die",      "tier": "top",   "desc": "Cancels the first 1 rolled anywhere in the hand."},
	"snake_eyes":  {"name": "Snake Eyes Die",  "tier": "top",   "desc": "If it and another die both roll 1, it pays a huge jackpot instead of a penalty."},
}

const SHOP_ITEMS := {
	# Thinning the bag is powerful, because you only ever draw 6 dice no
	# matter how many you own -- pulling dead weight out raises the odds
	# that a draw is all specials. Until now only Basic Dice could go,
	# which left no way to clear out a special that stopped fitting the
	# build. "choose" items hand that decision to the player.
	"cull_basics": {
		"name": "Loaded Deal",
		"tier": "top",
		"desc": "Pulls 3 Basic Dice out of your bag for good.",
		"removes": 3,
	},
	"sweep_basics": {
		"name": "Clean Sweep",
		"tier": "top",
		"desc": "Pulls out EVERY Basic Die you own at once. The more you're carrying, the better this gets.",
		"removes": -1,
	},
	"broker": {
		"name": "The Broker",
		"tier": "mid",
		"desc": "Pick any one die in your bag and be rid of it -- special dice included.",
		"choose": 1,
	},
	"melt_down": {
		"name": "Melt Down",
		"tier": "top",
		"desc": "Pick any two dice to scrap, and take back half of what they'd cost in the shop.",
		"choose": 2,
		"refund": 0.5,
	},
}


# --- unlock objectives ---------------------------------------------
# The heart of the replay loop: you start with three dice and earn the
# rest by doing things. A lost run still leaves the pool bigger than
# it was, so the next attempt genuinely starts stronger.
const STARTING_DIE_POOL: Array = ["base", "cracked", "loaded"]

const DIE_UNLOCKS := {
	# Early -- the weak and combo-piece dice. Reachable in a run or two.
	"anchor":      "Go bust for the first time",
	"bone":        "Reach round 3",
	"clockwork":   "Clear a round using 12 rolls or fewer",
	"prism":       "Roll four 6s in a single hand",
	"echo":        "Carry 10 dice in your bag at once",
	"lucky_charm": "Clear a round with 8 or more rolls to spare",
	"ivory":       "Clear 3 rounds in a single run",

	# Mid
	"hollow":      "Roll five 6s in a single hand",
	"mimic":       "Own 6 different kinds of die at the same time",
	"tithe":       "Spend $300 in the shop across all runs",
	"rusted":      "Reach round 6",
	"sable":       "Reach round 8 still carrying 8 Basic Dice",
	"chisel":      "Buy the Loaded Deal twice",
	"warden":      "Take 8 separate penalties in one round",
	"ashen":       "Earn $200 in a single round",
	"feather":     "Beat a boss round",
	"grafted":     "Shatter 3 Glass Dice",

	# Late -- the genuinely strong dice, deliberately the last to arrive.
	# Power tracks objective difficulty on purpose: if the best dice
	# unlocked early, run 2 would be as strong as run 20 and there'd be
	# no reason to keep playing.
	"gilded":      "Land a single jackpot worth $250 or more",
	"serpent":     "Roll 400 ones in total",
	"glass":       "Roll at least one 6 in 6 hands in a row",
	"twin":        "Clear 8 rounds in a single run",
	"snake_eyes":  "Roll three 1s in a single hand",
	"coin":        "Land a 6 and a 1 in the same hand, 120 times",
	"mirror":      "Reach round 15",
}


# --- characters ----------------------------------------------------
# Each one is a different opening hand rather than a stat line, so the
# choice changes how a run plays from the first roll. Most are unlocked
# by unlocking the die they're built around, which gives the die
# unlocks a second payoff.
const CHARACTERS := {
	"regular": {
		"name": "The Regular",
		"blurb": "Six plain dice and no tricks. The way the game was meant to be played.",
		"dice": {"base": 6},
		"unlock": "",
	},
	"four_eyes": {
		"name": "Four Eyes",
		"blurb": "Two Glass Dice and nothing else. Almost every roll is a six -- until one isn't.",
		"dice": {"glass": 2},
		"rolls_bonus": -3,
		"unlock": "Unlock the Glass Die",
	},
	"gambler": {
		"name": "The Gambler",
		"blurb": "Four Coin Dice. Every face is a six or a one. No middle ground, ever.",
		"dice": {"coin": 4},
		"rolls_bonus": -7,
		"unlock": "As Four Eyes, reach round 5",
	},
	"watchmaker": {
		"name": "The Watchmaker",
		"blurb": "Six Clockwork Dice. Zero randomness -- you know every face before it lands.",
		"dice": {"clockwork": 6},
		"unlock": "As The Regular, reach round 12",
	},
	"understudy": {
		"name": "The Understudy",
		"blurb": "Three Mimics and three plain dice. Your bag decides what you are each round.",
		"dice": {"mimic": 3, "base": 3},
		"unlock": "As The Watchmaker, reach round 8",
	},
	"charmer": {
		"name": "The Snake Charmer",
		"blurb": "Two Snake Eyes and two plain dice. Built to want the worst face in the game.",
		"dice": {"snake_eyes": 2, "base": 2},
		"rolls_bonus": -4,
		"unlock": "As The Gambler, roll two 1s in a single hand",
	},
	"collector": {
		"name": "The Collector",
		"blurb": "Ten plain dice and three extra rolls. A deeper bag, though you still only draw six.",
		"dice": {"base": 10},
		"rolls_bonus": 3,
		"unlock": "As The Understudy, own 8 different kinds of die at once",
	},
	"ascetic": {
		"name": "The Ascetic",
		"blurb": "Three dice, but every six pays a quarter more. Fragile early, dangerous late.",
		"dice": {"base": 3},
		"six_bonus": 1.25,
		"unlock": "As The Collector, carry 16 dice in your bag at once",
	},
}


# --- relics ---------------------------------------------------------
# Permanent for the rest of the run, bought from the left half of the
# shop. They exist so a build can keep scaling after the bag is full:
# once you own the dice you want, relics are what turn them broken.
#
# The whole system is data-driven on purpose. A relic is a bag of named
# modifiers, and every rule below reads those modifiers through
# relic_mult()/relic_add()/relic_flag(). Adding the hundredth relic
# means adding a dictionary entry -- no new code anywhere -- as long as
# it only uses keys that already exist. Only genuinely structural
# effects need a flag, and there are deliberately very few of those.
#
# MULTIPLICATIVE keys stack as a product, ADDITIVE keys as a sum.
const RELIC_MULT_KEYS: Array = [
	"six_value_mult", "one_penalty_mult", "jackpot_mult", "die_price_mult",
	"reroll_cost_mult", "threshold_mult", "snake_mult", "boss_bonus_mult",
]
const RELIC_ADD_KEYS: Array = [
	"jackpot_add", "jackpot_steps", "rolls_add", "hand_add", "bag_cap_add",
	"shop_offers_add", "six_chance_add", "one_chance_add",
]

const RELIC_TIER_PRICE := {"common": 1.0 / 3.0, "rare": 1.0 / 2.0, "mythic": 3.0 / 4.0}
const RELIC_TIER_WEIGHT := {"common": 6.0, "rare": 2.5, "mythic": 1.0}
const RELIC_OFFERS: int = 2

const RELICS := {
	# --- common: small, steady numbers ---
	"cracked_vault":  {"name": "Cracked Vault",  "tier": "common", "icon": 0,
		"desc": "Every 6 pays 15% more.", "mods": {"six_value_mult": 1.15}},
	"steady_hand":    {"name": "Steady Hand",    "tier": "common", "icon": 1,
		"desc": "+3 rolls every round.", "mods": {"rolls_add": 3}},
	"padded_felt":    {"name": "Padded Felt",    "tier": "common", "icon": 2,
		"desc": "Ones cost 25% less.", "mods": {"one_penalty_mult": 0.75}},
	"wide_pockets":   {"name": "Wide Pockets",   "tier": "common", "icon": 3,
		"desc": "Your bag holds 5 more dice.", "mods": {"bag_cap_add": 5}},
	"bookkeeper":     {"name": "Bookkeeper",     "tier": "common", "icon": 4,
		"desc": "Dice in the shop cost 25% less.", "mods": {"die_price_mult": 0.75}},
	"rabbits_foot":   {"name": "Rabbit's Foot",  "tier": "common", "icon": 5,
		"desc": "Every die gains +2% chance of a 6.", "mods": {"six_chance_add": 0.02}},
	"merchants_nod":  {"name": "Merchant's Nod", "tier": "common", "icon": 6,
		"desc": "One extra die on offer in every shop.", "mods": {"shop_offers_add": 1}},
	"second_wind":    {"name": "Second Wind",    "tier": "common", "icon": 7,
		"desc": "Rerolls cost 40% less.", "mods": {"reroll_cost_mult": 0.6}},
	"deep_draw":      {"name": "Deep Draw",      "tier": "common", "icon": 8,
		"desc": "Draw 1 more die each round.", "mods": {"hand_add": 1}},

	# --- rare: shapes a build ---
	"gilded_cup":     {"name": "Gilded Cup",     "tier": "rare", "icon": 9,
		"desc": "Each extra 6 in a hand multiplies by 1.8x instead of 1.5x.",
		"mods": {"jackpot_add": 0.3}},
	"hollow_crown":   {"name": "Hollow Crown",   "tier": "rare", "icon": 10,
		"desc": "The jackpot applies one extra time, so even a lone 6 pays 1.5x.",
		"mods": {"jackpot_steps": 1}},
	# Shifting the odds on every die at once turned out to be the single
	# strongest thing a relic can do -- at +8% this beat most mythics
	# from the rare slot.
	"weighted_bones": {"name": "Weighted Bones", "tier": "rare", "icon": 11,
		"desc": "+4% chance of a 6, -2% chance of a 1, on every die.",
		"mods": {"six_chance_add": 0.04, "one_chance_add": -0.02}},
	"twin_fates":     {"name": "Twin Fates",     "tier": "rare", "icon": 12,
		"desc": "Draw 2 more dice each round.", "mods": {"hand_add": 2}},
	"glass_casket":   {"name": "Glass Casket",   "tier": "rare", "icon": 13,
		"desc": "Glass Dice never shatter, and their ones cost the normal amount.",
		"mods": {}, "flags": ["glass_unbreakable"]},
	"tax_haven":      {"name": "Tax Haven",      "tier": "rare", "icon": 14,
		"desc": "The first reroll of each side, in every shop, is free.",
		"mods": {}, "flags": ["free_first_reroll"]},
	"pit_boss":       {"name": "Pit Boss",       "tier": "rare", "icon": 15,
		"desc": "Beating a boss pays double.", "mods": {"boss_bonus_mult": 2.0}},
	"serpents_coil":  {"name": "Serpent's Coil", "tier": "rare", "icon": 16,
		"desc": "Ones cost you nothing at all, but sixes pay 20% less.",
		"mods": {"one_penalty_mult": 0.0, "six_value_mult": 0.8}},
	"broken_glass":   {"name": "Broken Hourglass", "tier": "rare", "icon": 17,
		"desc": "+8 rolls every round, but the target is 15% higher.",
		"mods": {"rolls_add": 8, "threshold_mult": 1.15}},

	# --- mythic: run-defining ---
	"snakes_ascension": {"name": "Snake's Ascension", "tier": "mythic", "icon": 18,
		"desc": "Every 6 becomes a 1. Ordinary ones pay a little, every Snake Eyes Die cashes in rather than just the first, and those payouts jackpot together. Weak alone, devastating with a bag of snakes.",
		"mods": {}, "flags": ["sixes_become_ones", "snake_eyes_all_pay", "ones_jackpot"]},
	"bloodletting":   {"name": "Bloodletting",   "tier": "mythic", "icon": 19,
		"desc": "Ones pay you half a six instead of costing you anything.",
		"mods": {}, "flags": ["ones_pay"]},
	"mirror_of_fates":{"name": "Mirror of Fates","tier": "mythic", "icon": 20,
		"desc": "Each extra 6 in a hand multiplies by 2.25x instead of 1.5x. Six sixes pay 57x rather than 7x.",
		"mods": {"jackpot_mult": 1.5}},
	"house_edge":     {"name": "The House Edge", "tier": "mythic", "icon": 21,
		"desc": "Sixes pay 60% more. So do ones, against you.",
		"mods": {"six_value_mult": 1.6, "one_penalty_mult": 1.6}},
	"eternal_bag":    {"name": "Eternal Bag",    "tier": "mythic", "icon": 22,
		"desc": "Your bag holds 10 more dice and you draw 2 more each round.",
		"mods": {"bag_cap_add": 10, "hand_add": 2}},
	"venom_tithe":    {"name": "Venom Tithe",    "tier": "rare", "icon": 23,
		"desc": "Snake Eyes payouts are doubled.", "mods": {"snake_mult": 2.0}},
	"midas_seal":     {"name": "Midas Seal",     "tier": "mythic", "icon": 24,
		"desc": "Sixes pay double, but every round asks 30% more of you.",
		"mods": {"six_value_mult": 2.0, "threshold_mult": 1.3}},
}

# --- boss rounds ---------------------------------------------------
# Every BOSS_INTERVAL rounds the rules bend. Each boss is a real
# drawback paired with a compensating twist, so it changes how you
# play rather than just raising the number.
const BOSSES := {
	"short_hand": {
		"name": "The Short Hand",
		"desc": "You draw only 4 dice -- but every 6 and every 1 hits twice as hard.",
		"hand_size": 4, "six_scale": 2.0, "one_scale": 2.0,
	},
	"cold_deck": {
		"name": "The Cold Deck",
		"desc": "Sixes pay half -- but the jackpot multiplier is doubled.",
		"six_scale": 0.5, "jackpot_scale": 2.0,
	},
	"viper": {
		"name": "The Viper",
		"desc": "Ones cost triple -- but sixes pay double.",
		"one_scale": 3.0, "six_scale": 2.0,
	},
	"hourglass": {
		"name": "The Hourglass",
		"desc": "Only 12 rolls -- but the target is a quarter lower.",
		"roll_budget": 12, "threshold_scale": 0.75,
	},
	"tax_man": {
		"name": "The Tax Man",
		"desc": "Every roll is taxed -- but the jackpot starts one step higher.",
		"per_roll_fee": 0.6, "jackpot_steps": 1,
	},
	"mirror_match": {
		"name": "The Mirror Match",
		"desc": "Every special die rolls as a Basic Die -- but all payouts are tripled.",
		"specials_off": true, "six_scale": 3.0,
	},
	# Ten bosses for ten boss rounds, so a full climb to round 100 can
	# face a different one each time without ever repeating.
	"the_pit": {
		"name": "The Pit",
		"desc": "You draw only 3 dice -- but the jackpot multiplier is tripled.",
		"hand_size": 3, "jackpot_scale": 3.0,
	},
	"the_ledger": {
		"name": "The Ledger",
		"desc": "The target is half again as high -- but you get 15 extra rolls.",
		"threshold_scale": 1.5, "roll_budget": 37,
	},
	"the_famine": {
		"name": "The Famine",
		"desc": "Sixes pay a quarter -- but every 1 you roll pays you instead of costing you.",
		"six_scale": 0.25, "one_scale": -1.0,
	},
	"the_gauntlet": {
		"name": "The Gauntlet",
		"desc": "Ones cost five times as much -- but the jackpot starts two steps higher.",
		"one_scale": 5.0, "jackpot_steps": 2,
	},
}

# --- run state -----------------------------------------------------
var money: float = 0.0:
	set(value):
		money = value
		money_changed.emit(money)

var rolls_remaining: int = ROUND_ROLL_BUDGET:
	set(value):
		rolls_remaining = value
		rolls_changed.emit(rolls_remaining)

var round_earnings: float = 0.0:
	set(value):
		round_earnings = value
		earnings_changed.emit(round_earnings, round_threshold)

var round_number: int = 1
var round_threshold: float = ROUND_THRESHOLD_BASE
var run_active: bool = true
var active_boss: String = ""        # "" when this isn't a boss round
var just_beat_boss: bool = false    # widens the next shop
# Two independent counters: rerolling the dice should not make relics
# more expensive, and the other way round. Both reset when the shop
# opens, so the price climbs within a visit and starts fresh next time.
var dice_rerolls: int = 0
var relic_rerolls: int = 0
var owned_relics: Array = []       # permanent for this run, cleared on a new one
var bosses_faced: Array = []       # so a climb never meets the same boss twice

var dice_bag: Array = []
var current_hand: Array = []
# The shop pool is snapshotted when a run begins, so a die unlocked
# mid-run shows up in the NEXT one. Without this, a single deep run
# unlocks nearly everything and every later run starts equally strong
# -- there'd be no progression to feel.
var run_die_pool: Array = []
# set by the character screen so main.tscn knows whether to pick up a
# suspended run or start a fresh one
var resume_pending: bool = false

# --- meta-progression (saved per slot) ------------------------------
var unlocked_die_kinds: Array = STARTING_DIE_POOL.duplicate()
var unlocked_characters: Array = ["regular"]
var selected_character: String = "regular"
var achievements_unlocked: Dictionary = {}
var best_round: int = 0
var runs_played: int = 0
# How far the climb currently goes. 1 means the run ends after the
# round-10 boss; each boss beaten adds a tier, up to round 100. This is
# what turns a run from an open-ended survival into a target you clear
# and then push further next time.
var boss_tier: int = 1
var tutorial_done: bool = false
var tutorial_opt_in: bool = true       # the checkbox's own saved state
var tutorial_requested: bool = false   # set by the character screen
var stats: Dictionary = {}      # lifetime counters, saved
var run_stats: Dictionary = {}  # per-run counters, never saved

const SAVE_SLOTS: int = 3
var current_slot: int = 1

# ===================================================================
# run lifecycle
# ===================================================================

func start_new_run() -> void:
	# wipe run state back to a fresh bag of 6 plain dice. unlocks,
	# achievements and lifetime stats deliberately survive this --
	# that carry-over is what makes the next run start stronger
	round_number = 1
	active_boss = ""
	just_beat_boss = false
	round_threshold = threshold_for_round(1)
	run_active = true
	dice_bag = []
	var loadout: Dictionary = CHARACTERS.get(selected_character, CHARACTERS["regular"])["dice"]
	for kind in loadout.keys():
		for i in range(loadout[kind]):
			dice_bag.append(DieData.new(kind))
	run_stats = {
		"six_streak": 0, "rounds_cleared": 0,
		"ones_this_round": 0, "penalties_this_round": 0,
	}
	run_die_pool = unlocked_die_kinds.duplicate()
	owned_relics = []
	bosses_faced = []
	relics_changed.emit(owned_relics)
	clear_suspended_run()
	money = 0.0
	round_earnings = 0.0
	rolls_remaining = budget_for_round(1)
	bag_changed.emit(dice_bag)
	draw_hand()
	round_advanced.emit(round_number, round_threshold)

func target_round() -> int:
	# the round this climb ends on, if you get there
	return boss_tier * BOSS_INTERVAL

func is_boss_round(n: int) -> bool:
	return n % BOSS_INTERVAL == 0

func relic_mult(key: String) -> float:
	# multiplicative modifiers fold into a product, so two 20% boosts
	# compound rather than flatly adding to 40%
	var v := 1.0
	for id in owned_relics:
		v *= float(RELICS[id].get("mods", {}).get(key, 1.0))
	return v

func relic_add(key: String) -> float:
	var v := 0.0
	for id in owned_relics:
		v += float(RELICS[id].get("mods", {}).get(key, 0.0))
	return v

func relic_flag(key: String) -> bool:
	# structural effects that can't be expressed as a number. Kept few
	# on purpose -- every flag is a branch someone has to maintain.
	for id in owned_relics:
		if key in RELICS[id].get("flags", []):
			return true
	return false

func relic_price(id: String) -> float:
	return round_threshold * float(RELIC_TIER_PRICE[RELICS[id]["tier"]])

func can_buy_relic(id: String) -> bool:
	return not owned_relics.has(id) and money >= relic_price(id)

func buy_relic(id: String) -> bool:
	if not can_buy_relic(id):
		return false
	var cost: float = relic_price(id)
	money -= cost
	_bump("shop_spend", cost)
	owned_relics.append(id)
	_bump("relics_taken", 1)
	relics_changed.emit(owned_relics)
	return true

func bag_cap() -> int:
	return MAX_BAG_SIZE + int(relic_add("bag_cap_add"))

func boss_modifier(key: String, fallback):
	# reads one field off the active boss, or the fallback when there
	# isn't one. every rule that a boss can bend goes through here
	if active_boss == "":
		return fallback
	return BOSSES[active_boss].get(key, fallback)

func threshold_for_round(n: int) -> float:
	var base: float = ROUND_THRESHOLD_BASE * pow(ROUND_THRESHOLD_GROWTH, n - 1)
	if is_boss_round(n):
		base *= BOSS_THRESHOLD_SCALE
	return base * float(boss_modifier("threshold_scale", 1.0)) * relic_mult("threshold_mult")

func budget_for_round(_n: int) -> int:
	# a boss can override the budget outright; a character shifts it.
	# floored so no combination can leave you with too few rolls to play
	var base: int = int(boss_modifier("roll_budget", ROUND_ROLL_BUDGET))
	return max(base + int(character_modifier("rolls_bonus", 0)) + int(relic_add("rolls_add")), 6)

func draw_hand() -> void:
	# sample dice from the bag for this round. non-destructive -- they
	# go back afterward, so a bigger bag means more variety, not a
	# shrinking deck. Feather Dice ride along without taking a slot.
	var limit: int = int(boss_modifier("hand_size", HAND_SIZE)) + int(relic_add("hand_add"))
	var feathers: Array = []
	var normal: Array = []
	for die in dice_bag:
		if die.active_kind() == "feather":
			feathers.append(die)
		else:
			normal.append(die)
	# capped, because an uncapped hand size is the one thing that
	# scales forever and runs away from every other die
	feathers = feathers.slice(0, min(MAX_FEATHER_SLOTS, feathers.size()))
	normal.shuffle()
	current_hand = normal.slice(0, min(limit, normal.size()))
	current_hand.append_array(feathers)

	var kinds: Array = []
	for die in dice_bag:
		kinds.append(die.kind)
	for die in dice_bag:
		die.on_round_start(kinds, round_number)

	hand_drawn.emit(current_hand)

func face_probabilities() -> Dictionary:
	# Relics can shift the odds on every die at once. Whatever they add
	# to the 6 (or take off the 1) comes out of the faces in between, so
	# the six weights always still describe a real die.
	var p6: float = 1.0 / 6.0 + relic_add("six_chance_add")
	var p1: float = max(1.0 / 6.0 + relic_add("one_chance_add"), 0.0)
	var rest: float = max(1.0 - p6 - p1, 0.0) / 4.0
	return {1: p1, 2: rest, 3: rest, 4: rest, 5: rest, 6: max(p6, 0.0)}

func one_penalty() -> float:
	return VALUE_PER_SIX * ONE_PENALTY_RATIO * float(boss_modifier("one_scale", 1.0)) \
		* relic_mult("one_penalty_mult")

func character_modifier(key: String, fallback):
	# reads one field off the chosen character, or the fallback
	return CHARACTERS.get(selected_character, {}).get(key, fallback)

func six_value() -> float:
	return VALUE_PER_SIX * float(boss_modifier("six_scale", 1.0)) \
		* float(character_modifier("six_bonus", 1.0)) * relic_mult("six_value_mult")

# ===================================================================
# rolling
# ===================================================================

func roll_hand() -> void:
	# Run in phases, because several dice need to see the whole hand
	# before their effect can resolve:
	#   1. every die rolls its own face
	#   2. copying dice (Mirror, Echo) overwrite theirs
	#   3. Serpent turns a neighbour into a six
	#   4. Warden marks the first 1 as cancelled
	#   5. tally payouts, penalties and the jackpot
	#   6. clean up whatever broke, burnt out or got culled
	if not run_active:
		return

	var specials_off: bool = bool(boss_modifier("specials_off", false))
	var ctx := {
		"probs": face_probabilities(),
		"base_count": count_kind("base"),
		"round": round_number,
		"specials_off": specials_off,
	}
	var size: int = current_hand.size()
	if size == 0:
		return

	# --- phase 1 ---
	var faces: Array = []
	for die in current_hand:
		faces.append(die.roll_face(ctx))
		die.on_rolled()   # one tick per die per hand -- see DieData.on_rolled()

	# a boss can switch every special off, in which case all the
	# hand-wide tricks below are skipped too, not just the odds
	var kinds: Array = []
	for die in current_hand:
		kinds.append("base" if specials_off else die.active_kind())

	# --- phase 2: copying dice read the ORIGINAL faces, so two of them
	# can't cascade off each other in the same hand ---
	var resolved: Array = faces.duplicate()
	for i in range(size):
		if kinds[i] == "mirror":
			# deliberately ignores other Mirrors: without this, a bag of
			# them copies each other's copies and the value runs away
			var best := 0
			for j in range(size):
				if j != i and kinds[j] != "mirror":
					best = max(best, faces[j])
			resolved[i] = best
		elif kinds[i] == "echo" and size > 1:
			resolved[i] = faces[(i - 1 + size) % size]
	faces = resolved

	# --- phase 3 ---
	for i in range(size):
		if kinds[i] == "serpent" and faces[i] == 1 and size > 1:
			faces[(i + 1) % size] = 6

	# Snake's Ascension turns every 6 into a 1, applied after the
	# copying and Serpent passes so those still see the real faces --
	# a Mirror should copy the six that was rolled, then have it turn.
	if relic_flag("sixes_become_ones"):
		for i in range(size):
			if faces[i] == 6:
				faces[i] = 1

	# --- phase 4 ---
	var warded: int = -1
	if kinds.has("warden"):
		for i in range(size):
			if faces[i] == 1:
				warded = i
				break

	# --- phase 5 ---
	var total_sixes := 0
	var live_ones := 0
	for i in range(size):
		if faces[i] == 6:
			total_sixes += 1
		elif faces[i] == 1 and i != warded:
			live_ones += 1

	var six_indices: Array = []
	var gain := 0.0
	var loss := 0.0
	var shattered: Array = []
	var chisel_culls := 0
	var phantom_sixes := 0
	var jackpot_doubled := false
	var snake_paid := false
	var snake_hits := 0           # how many Snake Eyes cashed in this hand
	var snake_subtotal := 0.0     # their combined payout, before the jackpot
	var penalties := 0

	# A running account of where the money came from, so the tray can
	# walk it die by die afterwards. Built here rather than reconstructed
	# later, because only this loop knows which branch each die took.
	var steps: Array = []

	loss += float(boss_modifier("per_roll_fee", 0.0)) * VALUE_PER_SIX

	for i in range(size):
		var die = current_hand[i]
		var k: String = kinds[i]
		var face: int = faces[i]

		if k == "tithe":
			loss += VALUE_PER_SIX * TITHE_FEE_RATIO

		if face == 6:
			die.on_six()
			if k == "prism" and total_sixes >= 3:
				phantom_sixes += 1
			match k:
				"loaded":
					var v: float = six_value() * die.payout_multiplier()
					gain += v
					steps.append({"i": i, "kind": k, "face": 6, "amount": v, "note": "pays flat"})
				"hollow":
					jackpot_doubled = true
					steps.append({"i": i, "kind": k, "face": 6, "amount": 0.0, "note": "doubles the jackpot"})
				"gilded":
					if total_sixes >= 3:
						six_indices.append(i)
					else:
						var gv: float = six_value() * die.payout_multiplier()
						gain += gv
						steps.append({"i": i, "kind": k, "face": 6, "amount": gv, "note": "needs 3+ sixes"})
				_:
					six_indices.append(i)
		elif face == 1 and i != warded:
			match k:
				"snake_eyes":
					# two 1s in one hand turns the worst face into the
					# best. only the first Snake Eyes cashes in, so
					# stacking them doesn't multiply the same payout
					if live_ones >= 2:
						_bump("snake_eyes_triggered", 1)
						# normally only the first Snake Eyes in a hand
						# pays, so stacking them does nothing. Snake's
						# Ascension lifts that, which is the entire
						# reason to take it
						if not snake_paid or relic_flag("snake_eyes_all_pay"):
							var sv: float = six_value() * SNAKE_EYES_PAYOUT * relic_mult("snake_mult")
							snake_subtotal += sv
							snake_hits += 1
							steps.append({"i": i, "kind": k, "face": 1, "amount": sv, "note": "snake eyes"})
							snake_paid = true
					else:
						var sp: float = one_penalty() * die.penalty_multiplier
						loss += sp
						penalties += 1
						steps.append({"i": i, "kind": k, "face": 1, "amount": -sp, "note": ""})
				"chisel":
					chisel_culls += 1
					steps.append({"i": i, "kind": k, "face": 1, "amount": 0.0, "note": "thins the bag"})
				"glass":
					var gp: float = one_penalty() * die.penalty_multiplier
					if relic_flag("glass_unbreakable"):
						# Glass Casket: survives, and pays the ordinary
						# penalty rather than the tenfold one
						loss += gp
						steps.append({"i": i, "kind": k, "face": 1, "amount": -gp, "note": "held together"})
					else:
						gp *= 10.0
						loss += gp
						shattered.append(i)
						steps.append({"i": i, "kind": k, "face": 1, "amount": -gp, "note": "SHATTERED"})
					penalties += 1
				_:
					if relic_flag("ones_pay"):
						# Bloodletting: the worst face becomes income
						gain += six_value() * 0.5
						steps.append({"i": i, "kind": k, "face": 1, "amount": six_value() * 0.5, "note": "bloodletting"})
					elif relic_flag("sixes_become_ones"):
						steps.append({"i": i, "kind": k, "face": 1, "amount": six_value() * 0.25, "note": "ascension"})
						# Under Snake's Ascension an ordinary 1 pays a
						# little. Without this the relic is instant death
						# for anyone who takes it without a bag of snakes
						# -- it removed every source of income at once.
						# A trap you can recover from is a gamble; one
						# that ends the run on pickup is just a mistake.
						gain += six_value() * 0.25
					else:
						var op: float = one_penalty() * die.penalty_multiplier
						loss += op
						penalties += 1
						steps.append({"i": i, "kind": k, "face": 1, "amount": -op, "note": ""})

	# Snake Eyes payouts jackpot the same way sixes do once Snake's
	# Ascension is in play. Without this the inverted build earns a flat
	# amount per snake die -- linear income against a threshold that
	# compounds, so it always loses eventually no matter how many snakes
	# are in the bag. Letting ones compound is what makes the inversion
	# a real build rather than a trap.
	if snake_hits > 0:
		var sfactor: float = (MULTI_SIX_FACTOR + relic_add("jackpot_add")) * relic_mult("jackpot_mult")
		var ssteps: int = max(snake_hits - 1, 0) if relic_flag("ones_jackpot") else 0
		gain += snake_subtotal * pow(sfactor, ssteps)

	# jackpot: eligible sixes share one compounding multiplier, stepped
	# up by Prism and by a boss, and scaled by Hollow
	var jackpot := 0.0
	var six_count: int = six_indices.size()
	if six_count > 0:
		var subtotal := 0.0
		for i in six_indices:
			subtotal += six_value() * current_hand[i].payout_multiplier()
		var factor: float = (MULTI_SIX_FACTOR + relic_add("jackpot_add")) \
			* float(boss_modifier("jackpot_scale", 1.0)) * relic_mult("jackpot_mult")
		if jackpot_doubled:
			factor *= 2.0
		var jsteps: int = max(six_count - 1 + phantom_sixes
			+ int(boss_modifier("jackpot_steps", 0)) + int(relic_add("jackpot_steps")), 0)
		jackpot = subtotal * pow(factor, jsteps)
		gain += jackpot
		# every six in the pool is listed, then the multiplier that was
		# applied across all of them, so the readout can build to it
		for i in six_indices:
			steps.append({"i": i, "kind": current_hand[i].active_kind(), "face": 6,
				"amount": six_value() * current_hand[i].payout_multiplier(), "note": ""})
		if jsteps > 0:
			steps.append({"i": -1, "kind": "jackpot", "face": 0,
				"amount": jackpot - subtotal,
				"note": "%d sixes  x%.2f" % [six_count, pow(factor, jsteps)]})

	for i in six_indices:
		var die = current_hand[i]
		if kinds[i] == "bone" and randf() < BONE_BONUS_CHANCE:
			var bonus_face: int = die.roll_face(ctx)
			if bonus_face == 6:
				gain += six_value()
			elif bonus_face == 1:
				loss += one_penalty()

	# both totals floor at zero so a rough opening can't dig a hole
	var net: float = gain - loss
	money = max(money + net, 0.0)
	round_earnings = max(round_earnings + net, 0.0)
	rolls_remaining -= 1

	# --- phase 6: cleanup ---
	for i in shattered:
		current_hand[i].broken = true
		for die in dice_bag:
			die.on_glass_shattered()

	var before: int = dice_bag.size()
	if chisel_culls > 0:
		var kept: Array = []
		for die in dice_bag:
			if chisel_culls > 0 and die.active_kind() == "base":
				chisel_culls -= 1
			else:
				kept.append(die)
		dice_bag = kept

	# The roll is announced while the hand is still WHOLE, so every die
	# has something on screen to land on. Pruning first meant a
	# shattered Glass Die shrank the hand before the throw played, the
	# tray rebuilt itself mid-roll, and the rest of the hand looked like
	# it had never been rolled -- which mattered, because those other
	# dice may well have paid enough to cover the break.
	_track_roll(faces, total_sixes, live_ones, penalties, shattered.size(), jackpot)
	roll_resolved.emit(faces, gain, loss, _log_line(faces, gain, loss), steps)

	# only now is anything that broke or wore out taken away
	var hand_before: int = current_hand.size()
	dice_bag = dice_bag.filter(func(d): return not d.broken and not d.exhausted)
	current_hand = current_hand.filter(func(d): return not d.broken and not d.exhausted)
	if dice_bag.size() != before:
		bag_changed.emit(dice_bag)
	if current_hand.size() != hand_before:
		hand_pruned.emit(current_hand)

	_check_achievements(total_sixes, shattered.size() > 0)
	_check_round_progress()

func _log_line(faces: Array, gain: float, loss: float) -> String:
	var net := gain - loss
	var sign_char: String = "+" if net >= 0 else "-"
	return "Rolled %s  %s$%.2f" % [str(faces), sign_char, abs(net)]

# ===================================================================
# rounds and bosses
# ===================================================================

func _check_round_progress() -> void:
	if round_earnings >= round_threshold:
		run_active = false
		if active_boss != "":
			just_beat_boss = true
			_bump("bosses_beaten", 1)
			# beating a boss pays a bonus on top, so the next climb
			# actually starts with something to spend
			money += round_threshold * 0.5 * relic_mult("boss_bonus_mult")
			# Beating the boss at the top of your climb ends the run as
			# a win and pushes the summit out by ten rounds. The next
			# run starts over but may go further, which is what makes a
			# finished climb feel like progress rather than an
			# arbitrary stopping point.
			if round_number >= target_round():
				best_round = max(best_round, round_number)
				runs_played += 1
				var was_final: bool = boss_tier >= MAX_BOSS_TIER
				if not was_final:
					boss_tier += 1
				run_active = false
				_evaluate_unlocks()
				clear_suspended_run()
				save_slot(current_slot)
				run_won.emit(round_number, boss_tier, was_final)
				return
		_bump("rounds_cleared", 1, true)
		_evaluate_unlocks()
		dice_rerolls = 0
		relic_rerolls = 0
		shop_opened.emit(generate_shop_offers(), generate_relic_offers())
	elif rolls_remaining <= 0:
		run_active = false
		if not achievements_unlocked.get("go_bust", false):
			_unlock("go_bust", "Bad Beat: lost a run")
		best_round = max(best_round, round_number)
		runs_played += 1
		_bump("busts", 1)
		_evaluate_unlocks()
		clear_suspended_run()
		save_slot(current_slot)
		run_ended.emit(round_number)

func advance_round() -> void:
	# called when the shop closes -- bump the round, roll a boss if
	# this one lands on the interval, refill the budget, draw a hand
	if round_number == 1 and not achievements_unlocked.get("beat_round_1", false):
		_unlock("beat_round_1", "First Blood: beat Round 1")
	round_number += 1
	run_stats["ones_this_round"] = 0
	run_stats["penalties_this_round"] = 0

	active_boss = ""
	if is_boss_round(round_number):
		# Never the same boss twice in one climb. There are exactly as
		# many bosses as boss rounds, so a full run to 100 meets each
		# one once; the fallback only matters if the roster shrinks.
		var ids: Array = []
		for id in BOSSES.keys():
			if not bosses_faced.has(id):
				ids.append(id)
		if ids.is_empty():
			ids = BOSSES.keys()
		active_boss = ids[randi() % ids.size()]
		bosses_faced.append(active_boss)

	round_threshold = threshold_for_round(round_number)
	rolls_remaining = budget_for_round(round_number)
	round_earnings = 0.0
	run_active = true
	draw_hand()
	_evaluate_unlocks()
	round_advanced.emit(round_number, round_threshold)
	if active_boss != "":
		boss_started.emit(active_boss, BOSSES[active_boss]["name"], BOSSES[active_boss]["desc"])

# ===================================================================
# shop
# ===================================================================

func offer_info(id: String) -> Dictionary:
	if DIE_CATALOG.has(id):
		return DIE_CATALOG[id]
	return SHOP_ITEMS.get(id, {})

func is_item(id: String) -> bool:
	return SHOP_ITEMS.has(id)

func die_price(id: String) -> float:
	# priced off the threshold you just cleared: 1/6 for basic dice,
	# 1/3 for mid-tier, 1/2 for the best ones, so prices track the
	# run's scale without needing a curve of their own
	var info: Dictionary = offer_info(id)
	var fraction: float = TIER_PRICE_FRACTION[info.get("tier", "mid")]
	return round_threshold * fraction * relic_mult("die_price_mult")

func count_kind(kind: String) -> int:
	var n: int = 0
	for die in dice_bag:
		if die.kind == kind:
			n += 1
	return n

func distinct_kinds() -> int:
	var seen: Dictionary = {}
	for die in dice_bag:
		seen[die.kind] = true
	return seen.size()

func can_buy(id: String) -> bool:
	if money < die_price(id):
		return false
	if is_item(id):
		var info: Dictionary = SHOP_ITEMS[id]
		# a thinning item is only worth offering when it would leave you
		# a hand to actually roll afterwards
		if info.has("choose"):
			return dice_bag.size() - int(info["choose"]) >= 2
		var need: int = int(info["removes"])
		if need < 0:
			return count_kind("base") >= 4      # Clean Sweep wants a real pile
		return count_kind("base") >= need
	return dice_bag.size() < bag_cap()

func item_needs_choice(id: String) -> int:
	# how many dice the player has to pick for this item, 0 if none
	return int(SHOP_ITEMS.get(id, {}).get("choose", 0))

func buy_item(id: String) -> bool:
	# for a "choose" item this only takes the payment -- the shop opens
	# the picker and calls apply_removal() once the player has decided
	if not can_buy(id):
		return false
	var cost: float = die_price(id)
	money -= cost
	_bump("shop_spend", cost)

	if item_needs_choice(id) > 0:
		return true

	var need: int = int(SHOP_ITEMS[id]["removes"])
	var kept: Array = []
	for die in dice_bag:
		if die.kind == "base" and (need < 0 or need > 0):
			if need > 0:
				need -= 1
			continue
		kept.append(die)
	dice_bag = kept
	_bump("bought_cull", 1)
	bag_changed.emit(dice_bag)
	_evaluate_unlocks()
	return true

func apply_removal(id: String, indices: Array) -> void:
	# removes the chosen dice and pays back a share of their shop value
	# if the item offers one
	var info: Dictionary = SHOP_ITEMS.get(id, {})
	var refund: float = float(info.get("refund", 0.0))
	var chosen: Dictionary = {}
	for i in indices:
		chosen[int(i)] = true
	var kept: Array = []
	for i in range(dice_bag.size()):
		if chosen.has(i):
			if refund > 0.0:
				money += die_price(dice_bag[i].kind) * refund
		else:
			kept.append(dice_bag[i])
	dice_bag = kept
	_bump("bought_cull", 1)
	bag_changed.emit(dice_bag)
	_evaluate_unlocks()

func buy_die(kind: String) -> bool:
	if not can_buy(kind):
		return false
	var cost: float = die_price(kind)
	money -= cost
	_bump("shop_spend", cost)
	dice_bag.append(DieData.new(kind))
	bag_changed.emit(dice_bag)
	if kind != "base" and not achievements_unlocked.get("buy_first_unique_die", false):
		_unlock("buy_first_unique_die", "Loose Change: bought your first special die")
	_evaluate_unlocks()
	return true

func _offer_pool() -> Array:
	var pool: Array = run_die_pool.duplicate()
	for id in SHOP_ITEMS.keys():
		if _item_effect_possible(id):
			pool.append(id)
	return pool

func _build_offers(count: int) -> Array:
	# Weighted by tier, so the best dice are the ones you have to hunt
	# for. One slot is reserved for a thinning item once the bag is
	# nearly full: without it the shop offers only dice you have no room
	# to buy, and money piles up with nothing to spend it on. Being at
	# the cap should be a decision -- pay to cull, then pay to upgrade --
	# not a dead end.
	var pool: Array = _offer_pool()
	var out: Array = []
	if dice_bag.size() >= bag_cap() - 1:
		var thinners: Array = []
		for id in SHOP_ITEMS.keys():
			if _item_effect_possible(id):
				thinners.append(id)
		if not thinners.is_empty():
			var pick: String = thinners[randi() % thinners.size()]
			out.append(pick)
			pool.erase(pick)
	out.append_array(_weighted_pick(pool, min(count - out.size(), pool.size())))
	return out

func generate_relic_offers() -> Array:
	# weighted the same way the dice are, so mythics are something you
	# hunt for rather than something you trip over
	var pool: Array = []
	for id in RELICS.keys():
		if not owned_relics.has(id):
			pool.append(id)
	var out: Array = []
	var count: int = min(RELIC_OFFERS, pool.size())
	while out.size() < count and pool.size() > 0:
		var total := 0.0
		for id in pool:
			total += float(RELIC_TIER_WEIGHT[RELICS[id]["tier"]])
		var roll := randf() * total
		var acc := 0.0
		var chosen: int = pool.size() - 1
		for i in range(pool.size()):
			acc += float(RELIC_TIER_WEIGHT[RELICS[pool[i]]["tier"]])
			if roll < acc:
				chosen = i
				break
		out.append(pool[chosen])
		pool.remove_at(chosen)
	return out

func generate_shop_offers() -> Array:
	# beating a boss earns an extra slot
	var count: int = SHOP_OFFERS_AFTER_BOSS if just_beat_boss else SHOP_OFFERS
	just_beat_boss = false
	return _build_offers(count + int(relic_add("shop_offers_add")))

func _weighted_pick(pool: Array, count: int) -> Array:
	# weighted sample without replacement -- one offer can't appear twice
	var remaining: Array = pool.duplicate()
	var out: Array = []
	while out.size() < count and remaining.size() > 0:
		var total := 0.0
		for id in remaining:
			total += float(TIER_WEIGHT.get(offer_info(id).get("tier", "mid"), 1.0))
		var roll := randf() * total
		var acc := 0.0
		var chosen: int = remaining.size() - 1
		for i in range(remaining.size()):
			acc += float(TIER_WEIGHT.get(offer_info(remaining[i]).get("tier", "mid"), 1.0))
			if roll < acc:
				chosen = i
				break
		out.append(remaining[chosen])
		remaining.remove_at(chosen)
	return out

func reroll_cost(side: String) -> float:
	# "dice" or "relics" -- each side keeps its own escalating price
	var used: int = dice_rerolls if side == "dice" else relic_rerolls
	# The relic makes only the FIRST reroll of each shop free. Making
	# every reroll free meant a player could spin both sides until the
	# offers were perfect, every single shop, which trivialised the
	# whole economy within a couple of rounds.
	if used == 0 and relic_flag("free_first_reroll"):
		return 0.0
	return round_threshold * REROLL_BASE_FRACTION * pow(REROLL_GROWTH, used) \
		* relic_mult("reroll_cost_mult")

func can_reroll(side: String) -> bool:
	return money >= reroll_cost(side)

func reroll_dice_offers() -> Array:
	# charges and hands back a fresh set of dice. returns empty when it
	# can't be paid for, so the caller leaves the current offers alone
	if not can_reroll("dice"):
		return []
	var cost: float = reroll_cost("dice")
	money -= cost
	_bump("shop_spend", cost)
	dice_rerolls += 1
	return _build_offers(SHOP_OFFERS + int(relic_add("shop_offers_add")))

func reroll_relic_offers() -> Array:
	if not can_reroll("relics"):
		return []
	var cost: float = reroll_cost("relics")
	money -= cost
	_bump("shop_spend", cost)
	relic_rerolls += 1
	return generate_relic_offers()

func _item_effect_possible(id: String) -> bool:
	# ignores price -- purely "would this item change anything?"
	var info: Dictionary = SHOP_ITEMS[id]
	if info.has("choose"):
		return dice_bag.size() - int(info["choose"]) >= 2
	var need: int = int(info["removes"])
	if need < 0:
		return count_kind("base") >= 4
	return count_kind("base") >= need

func bag_counts() -> Dictionary:
	var counts: Dictionary = {}
	for die in dice_bag:
		counts[die.kind] = counts.get(die.kind, 0) + 1
	return counts

# ===================================================================
# stats and unlocks
# ===================================================================

func _bump(key: String, amount, run_only: bool = false) -> void:
	# one entry point for every counter, so tracking can't drift.
	# everything is also filed under the character who did it, which is
	# what lets an objective say "as The Gambler, ..."
	if run_only:
		run_stats[key] = run_stats.get(key, 0) + amount
		return
	stats[key] = stats.get(key, 0) + amount
	var scoped: String = "%s/%s" % [selected_character, key]
	stats[scoped] = stats.get(scoped, 0) + amount

func _peak(key: String, value) -> void:
	# records a personal best rather than a running total, both overall
	# and for the character who set it
	if value > stats.get(key, 0):
		stats[key] = value
	var scoped: String = "%s/%s" % [selected_character, key]
	if value > stats.get(scoped, 0):
		stats[scoped] = value

func _low(key: String, value) -> void:
	# same idea for stats where lower is better
	if value < stats.get(key, 999999):
		stats[key] = value
	var scoped: String = "%s/%s" % [selected_character, key]
	if value < stats.get(scoped, 999999):
		stats[scoped] = value

func char_stat(character: String, key: String):
	# reads a stat scoped to one character
	return stats.get("%s/%s" % [character, key], 0)

func _track_roll(faces: Array, sixes: int, ones: int, penalties: int, shattered: int, jackpot: float) -> void:
	# every counter an unlock objective can ask about
	_peak("max_sixes_in_hand", sixes)
	_peak("max_ones_in_hand", ones)
	_peak("max_bag_size", dice_bag.size())
	_peak("max_distinct_kinds", distinct_kinds())
	_peak("max_jackpot", jackpot)
	_peak("max_round_earnings", round_earnings)
	_bump("ones_total", ones)
	_bump("glass_shattered", shattered)
	_bump("penalties_this_round", penalties, true)
	_bump("ones_this_round", ones, true)
	if sixes > 0 and ones > 0:
		_bump("six_and_one_hands", 1)
	# a streak of hands that each landed at least one six
	if sixes > 0:
		run_stats["six_streak"] = run_stats.get("six_streak", 0) + 1
		_peak("max_six_streak", run_stats["six_streak"])
	else:
		run_stats["six_streak"] = 0
	_peak("max_penalties_in_round", run_stats.get("penalties_this_round", 0))
	if round_earnings >= round_threshold:
		# these can only be judged at the moment a round is cleared
		_peak("max_rolls_spare", rolls_remaining)
		_low("fewest_rolls_to_clear", budget_for_round(round_number) - rolls_remaining)
		if round_number >= 8:
			_peak("basics_at_round_8", count_kind("base"))
	_peak("best_round_reached", round_number)
	_peak("max_rounds_in_run", run_stats.get("rounds_cleared", 0))

func _objective_met(kind: String) -> bool:
	# one condition per unlockable die, in the same order as
	# DIE_UNLOCKS above so the two can be read side by side
	match kind:
		"anchor":      return stats.get("busts", 0) >= 1
		"bone":        return stats.get("best_round_reached", 0) >= 3
		"clockwork":   return stats.get("fewest_rolls_to_clear", 999) <= 12
		"prism":       return stats.get("max_sixes_in_hand", 0) >= 4
		"echo":        return stats.get("max_bag_size", 0) >= 10
		"lucky_charm": return stats.get("max_rolls_spare", 0) >= 8
		"ivory":       return stats.get("max_rounds_in_run", 0) >= 3

		"hollow":      return stats.get("max_sixes_in_hand", 0) >= 5
		"mimic":       return stats.get("max_distinct_kinds", 0) >= 6
		"tithe":       return stats.get("shop_spend", 0) >= 300
		"rusted":      return stats.get("best_round_reached", 0) >= 6
		"sable":       return stats.get("basics_at_round_8", 0) >= 8
		"chisel":      return stats.get("bought_cull", 0) >= 2
		"warden":      return stats.get("max_penalties_in_round", 0) >= 8
		"ashen":       return stats.get("max_round_earnings", 0) >= 200
		"feather":     return stats.get("bosses_beaten", 0) >= 1
		"grafted":     return stats.get("glass_shattered", 0) >= 3

		"gilded":      return stats.get("max_jackpot", 0) >= 250
		"serpent":     return stats.get("ones_total", 0) >= 400
		"glass":       return stats.get("max_six_streak", 0) >= 6
		"twin":        return stats.get("max_rounds_in_run", 0) >= 8
		"snake_eyes":  return stats.get("max_ones_in_hand", 0) >= 3
		"coin":        return stats.get("six_and_one_hands", 0) >= 120
		"mirror":      return stats.get("best_round_reached", 0) >= 15
	return false

func _character_unlocked(id: String) -> bool:
	# Deliberately scoped to WHO did it. Unlocking the next character
	# means putting a run in with the last one, so the roster gets
	# played instead of everyone settling on a favourite.
	match id:
		"regular":    return true
		"four_eyes":  return unlocked_die_kinds.has("glass")
		"watchmaker": return char_stat("regular", "best_round_reached") >= 12
		"gambler":    return char_stat("four_eyes", "best_round_reached") >= 5
		"understudy": return char_stat("watchmaker", "best_round_reached") >= 8
		"charmer":    return char_stat("gambler", "max_ones_in_hand") >= 2
		"collector":  return char_stat("understudy", "max_distinct_kinds") >= 8
		"ascetic":    return char_stat("collector", "max_bag_size") >= 16
	return false

func refresh_character_unlocks() -> bool:
	# returns whether anything new opened up, so the caller can shout
	var gained := false
	for id in CHARACTERS.keys():
		if unlocked_characters.has(id):
			continue
		if _character_unlocked(id):
			unlocked_characters.append(id)
			gained = true
			character_unlocked.emit(id, CHARACTERS[id]["name"], CHARACTERS[id]["unlock"])
	return gained

func _evaluate_unlocks() -> void:
	# checked after every roll, purchase and round change. announcing
	# an unlock mid-run is half the reward, so it fires immediately
	var earned := false
	for kind in DIE_UNLOCKS.keys():
		if unlocked_die_kinds.has(kind):
			continue
		if _objective_met(kind):
			unlocked_die_kinds.append(kind)
			earned = true
			die_unlocked.emit(kind, DIE_CATALOG[kind]["name"], DIE_UNLOCKS[kind])
	if refresh_character_unlocks():
		earned = true
	if earned:
		save_slot(current_slot)

func locked_objectives() -> Array:
	# what the bag panel shows as "still to earn"
	var out: Array = []
	for kind in DIE_UNLOCKS.keys():
		if not unlocked_die_kinds.has(kind):
			out.append({"kind": kind, "name": DIE_CATALOG[kind]["name"], "objective": DIE_UNLOCKS[kind]})
	return out

func _check_achievements(six_count: int, any_shattered: bool) -> void:
	if six_count >= 3 and not achievements_unlocked.get("roll_three_sixes", false):
		_unlock("roll_three_sixes", "Triple Sixes: rolled three 6s at once")
	if any_shattered and not achievements_unlocked.get("survive_glass_shatter", false):
		_unlock("survive_glass_shatter", "Cracked, Not Broken: survived a Glass Die shattering")

func _unlock(id: String, title: String) -> void:
	# written straight through so an unlock is never lost to a quit
	achievements_unlocked[id] = true
	save_slot(current_slot)
	achievement_unlocked.emit(id, title)

# ===================================================================
# save slots
# ===================================================================

func slot_path(slot: int) -> String:
	return "user://save_slot_%d.json" % slot

func slot_exists(slot: int) -> bool:
	return FileAccess.file_exists(slot_path(slot))

func slot_summary(slot: int) -> Dictionary:
	if not slot_exists(slot):
		return {"empty": true}
	var data: Dictionary = _read_slot(slot)
	return {
		"empty": false,
		"best_round": data.get("best_round", 0),
		"runs_played": data.get("runs_played", 0),
		"achievements": data.get("achievements", {}).size(),
		"dice_unlocked": data.get("unlocked_die_kinds", []).size(),
	}

func _read_slot(slot: int) -> Dictionary:
	var f := FileAccess.open(slot_path(slot), FileAccess.READ)
	if f == null:
		return {}
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	return parsed if parsed is Dictionary else {}

func load_slot(slot: int) -> void:
	current_slot = slot
	if not slot_exists(slot):
		unlocked_die_kinds = STARTING_DIE_POOL.duplicate()
		unlocked_characters = ["regular"]
		selected_character = "regular"
		achievements_unlocked = {}
		stats = {}
		best_round = 0
		runs_played = 0
		boss_tier = 1
		tutorial_done = false
		tutorial_opt_in = true
		save_slot(slot)
		return
	var data: Dictionary = _read_slot(slot)
	unlocked_die_kinds = data.get("unlocked_die_kinds", STARTING_DIE_POOL.duplicate())
	unlocked_characters = data.get("unlocked_characters", ["regular"])
	selected_character = data.get("selected_character", "regular")
	achievements_unlocked = data.get("achievements", {})
	stats = data.get("stats", {})
	boss_tier = int(data.get("boss_tier", 1))
	best_round = int(data.get("best_round", 0))
	runs_played = int(data.get("runs_played", 0))
	tutorial_done = bool(data.get("tutorial_done", false))
	tutorial_opt_in = bool(data.get("tutorial_opt_in", true))

func save_slot(slot: int) -> void:
	var f := FileAccess.open(slot_path(slot), FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify({
		"unlocked_die_kinds": unlocked_die_kinds,
		"boss_tier": boss_tier,
		"unlocked_characters": unlocked_characters,
		"selected_character": selected_character,
		"achievements": achievements_unlocked,
		"stats": stats,
		"best_round": best_round,
		"runs_played": runs_played,
		"tutorial_done": tutorial_done,
		"tutorial_opt_in": tutorial_opt_in,
	}))
	f.close()

func delete_slot(slot: int) -> void:
	# wipe a slot back to empty. the parked run goes with it -- erasing
	# mid-run used to leave a clean-looking profile that could still
	# resume the very run you thought you had deleted
	var dir := DirAccess.open("user://")
	if dir != null:
		dir.remove("save_slot_%d.json" % slot)
	clear_suspended_run(slot)
	# if the erased slot is the one currently loaded, drop its state from
	# memory as well, so nothing lingers to be re-saved later
	if slot == current_slot:
		unlocked_die_kinds = STARTING_DIE_POOL.duplicate()
		unlocked_characters = ["regular"]
		selected_character = "regular"
		achievements_unlocked = {}
		stats = {}
		best_round = 0
		runs_played = 0
		boss_tier = 1
		tutorial_done = false
		tutorial_opt_in = true
		resume_pending = false

# ===================================================================
# suspending a run
# ===================================================================
# Leaving mid-run parks the whole thing on disk so it can be resumed
# exactly where it was. Starting a new run or going bust wipes it.

func run_path(slot: int) -> String:
	return "user://run_slot_%d.json" % slot

func has_suspended_run() -> bool:
	return FileAccess.file_exists(run_path(current_slot))

func suspended_run_summary() -> Dictionary:
	# what the character screen puts on the Continue button
	if not has_suspended_run():
		return {}
	var f := FileAccess.open(run_path(current_slot), FileAccess.READ)
	if f == null:
		return {}
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	return parsed if parsed is Dictionary else {}

func suspend_run() -> void:
	# the hand holds the same DieData objects as the bag, so it's stored
	# as indices into the bag rather than as copies -- otherwise
	# resuming would split one die into two that drift apart
	if not run_active and dice_bag.is_empty():
		return
	var bag_data: Array = []
	for die in dice_bag:
		bag_data.append(die.to_dict())
	var hand_idx: Array = []
	for die in current_hand:
		var i: int = dice_bag.find(die)
		if i >= 0:
			hand_idx.append(i)

	var f := FileAccess.open(run_path(current_slot), FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify({
		"character": selected_character,
		"round_number": round_number,
		"round_threshold": round_threshold,
		"round_earnings": round_earnings,
		"money": money,
		"rolls_remaining": rolls_remaining,
		"active_boss": active_boss,
		"just_beat_boss": just_beat_boss,
		"run_active": run_active,
		"run_die_pool": run_die_pool,
		"run_stats": run_stats,
		"dice_rerolls": dice_rerolls,
		"relic_rerolls": relic_rerolls,
		"owned_relics": owned_relics,
		"bosses_faced": bosses_faced,
		"bag": bag_data,
		"hand": hand_idx,
	}))
	f.close()

func resume_run() -> bool:
	# rebuild the run from disk. returns false if there was nothing to
	# resume, so the caller can fall back to starting fresh
	var data: Dictionary = suspended_run_summary()
	if data.is_empty():
		return false

	selected_character = String(data.get("character", selected_character))
	dice_bag = []
	for entry in data.get("bag", []):
		dice_bag.append(DieData.from_dict(entry))
	current_hand = []
	for i in data.get("hand", []):
		var idx: int = int(i)
		if idx >= 0 and idx < dice_bag.size():
			current_hand.append(dice_bag[idx])

	round_number = int(data.get("round_number", 1))
	round_threshold = float(data.get("round_threshold", ROUND_THRESHOLD_BASE))
	active_boss = String(data.get("active_boss", ""))
	just_beat_boss = bool(data.get("just_beat_boss", false))
	run_active = bool(data.get("run_active", true))
	run_die_pool = data.get("run_die_pool", unlocked_die_kinds.duplicate())
	run_stats = data.get("run_stats", {})
	dice_rerolls = int(data.get("dice_rerolls", 0))
	relic_rerolls = int(data.get("relic_rerolls", 0))
	owned_relics = data.get("owned_relics", [])
	bosses_faced = data.get("bosses_faced", [])
	relics_changed.emit(owned_relics)

	# these use setters that emit, so they go last -- by then everything
	# the listening scenes might read is already in place
	money = float(data.get("money", 0.0))
	rolls_remaining = int(data.get("rolls_remaining", ROUND_ROLL_BUDGET))
	round_earnings = float(data.get("round_earnings", 0.0))

	bag_changed.emit(dice_bag)
	hand_drawn.emit(current_hand)
	round_advanced.emit(round_number, round_threshold)
	if active_boss != "":
		boss_started.emit(active_boss, BOSSES[active_boss]["name"], BOSSES[active_boss]["desc"])
	return true

func clear_suspended_run(slot: int = -1) -> void:
	# defaults to the active slot, but takes an explicit one so erasing
	# a profile can throw away that profile's parked run too
	var target: int = current_slot if slot < 0 else slot
	var dir := DirAccess.open("user://")
	if dir != null:
		dir.remove("run_slot_%d.json" % target)
