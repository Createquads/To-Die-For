extends Node
# Player settings, kept separate from run state so they survive
# everything -- new runs, save slots, quitting. Written to
# user://settings.cfg with ConfigFile and reapplied on boot.

signal settings_changed

const PATH: String = "user://settings.cfg"

var master_volume: float = 0.8
var sfx_volume: float = 0.8
var fullscreen: bool = false
var reduced_motion: bool = false   # kills screen shake / flashes when the juice pass lands
var show_die_numbers: bool = false # draws numerals instead of pips, for colourblind readability

# where the window sat before going fullscreen, so it can be put back
var _windowed_size: Vector2i = Vector2i(1280, 720)
var _windowed_pos: Vector2i = Vector2i(80, 80)

func _ready() -> void:
	load_settings()
	apply_all()

func load_settings() -> void:
	# read the config file, falling back to the defaults above
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	master_volume = cfg.get_value("audio", "master", master_volume)
	sfx_volume = cfg.get_value("audio", "sfx", sfx_volume)
	fullscreen = cfg.get_value("video", "fullscreen", fullscreen)
	reduced_motion = cfg.get_value("access", "reduced_motion", reduced_motion)
	show_die_numbers = cfg.get_value("access", "show_die_numbers", show_die_numbers)

func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("audio", "master", master_volume)
	cfg.set_value("audio", "sfx", sfx_volume)
	cfg.set_value("video", "fullscreen", fullscreen)
	cfg.set_value("access", "reduced_motion", reduced_motion)
	cfg.set_value("access", "show_die_numbers", show_die_numbers)
	cfg.save(PATH)

func apply_all() -> void:
	# push the current values into the engine, then tell any listening
	# scene to repaint (die.gd redraws when numerals get toggled)
	var master_idx: int = AudioServer.get_bus_index("Master")
	if master_idx >= 0:
		AudioServer.set_bus_volume_db(master_idx, linear_to_db(max(master_volume, 0.0001)))
		AudioServer.set_bus_mute(master_idx, master_volume <= 0.0)
	apply_window_mode()
	settings_changed.emit()

func apply_window_mode() -> void:
	# Fullscreen fills whatever monitor the window is currently on, at
	# that monitor's native resolution. Paired with the project's
	# keep_height stretch, the whole UI scales up to match instead of
	# sitting at 1280x720 in the middle of a big screen.
	var screen: int = DisplayServer.window_get_current_screen()
	var screen_size: Vector2i = DisplayServer.screen_get_size(screen)

	if fullscreen:
		# remember where the window was, so leaving fullscreen can put
		# it back rather than dumping it at some default
		if DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_WINDOWED:
			_windowed_size = DisplayServer.window_get_size()
			_windowed_pos = DisplayServer.window_get_position()
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
		# borderless fullscreen usually sizes itself, but some platforms
		# keep the old window size until told otherwise
		DisplayServer.window_set_size(screen_size)
		return

	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	# never restore a window bigger than the monitor it lands on
	var restore: Vector2i = Vector2i(
		min(_windowed_size.x, screen_size.x),
		min(_windowed_size.y, screen_size.y)
	)
	DisplayServer.window_set_size(restore)
	DisplayServer.window_set_position(
		DisplayServer.screen_get_position(screen) + (screen_size - restore) / 2
	)

func set_value(key: String, value) -> void:
	# single entry point the settings menu calls for every control,
	# so saving and applying can never be forgotten
	match key:
		"master_volume": master_volume = value
		"sfx_volume": sfx_volume = value
		"fullscreen": fullscreen = value
		"reduced_motion": reduced_motion = value
		"show_die_numbers": show_die_numbers = value
	save_settings()
	apply_all()
